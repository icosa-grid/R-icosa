## ---- fig.out=8, fig.width=4--------------------------------------------------
library(icosa)
gr <- hexagrid(deg=10, sf=TRUE) # create grid
plot(gr)

