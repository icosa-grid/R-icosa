# This chunk of the code will use the created grid structures as as hosts
# and link data to them using layers similar to the raster package

# the most important thing with this is that it can be useful for 
# both the trigrid and the hexagrid objects!


# S4 version of the layering

#gridlayer basic class
	#class definition
	gridlayer <- setClass(
		"gridlayer",
		
		slots= c(
			grid= "character",
			tesselation ="numeric",
			gridclass = "character",
			names = "character",
			values= "vector",
			length= "integer"
		)
	
	)

# methods for the gridlayer	
# show	
	setMethod("show", signature ="gridlayer",
		definition = function(object){
		#	cat(paste(class(object), "of", object@grid ,"with", object@length, class(object@values), "values\n", sep=" "))
		#	cat(object@values, fill=TRUE)
			
			actGrid<-get(object@grid)
			
			
			cat(paste("class        : ", class(object),"\n", sep=""))
			cat(paste("linked grid  : \'", object@grid,"\' (name), ", class(actGrid)," (class), ",
				paste(as.character(object@tesselation), collapse=",")
				, " (tesselation)", "\n", sep=""))
			cat(paste("dimensions   : ", length(object), " (values)", " @ ", "mean edge length: ",round(actGrid@edgeLength[1],2), " km, " ,round(actGrid@edgeLength[2],2), " degrees",  "\n" ,sep=""))
			if(sum(is.na(object@values))==length(object)){
				mx<-NA
				mn<-NA
			}else{
				mx<-max(object@values, na.rm=T)
				mn<-min(object@values, na.rm=T)
			}
			
			cat(paste("values       : ", class(object@values)), "\n")
			cat(paste("max value    : ", mx), "\n")
			cat(paste("min value    : ", mn), "\n")
			cat(paste("missing      : ", sum(is.na(object@values))), "\n")
			
		} 
	)

	
#basic operators for the layers	
{

	# stats
	setMethod("Math", signature="gridlayer", 
	definition=function(x){
		callGeneric(x@values)
	}
	)
	
	setMethod("Summary", signature="gridlayer", 
	definition=function(x){
		callGeneric(x@values)
	}
	)
	
	
	setMethod("Ops", signature=c("gridlayer", "numeric"),
	definition=function(e1,e2){
		callGeneric(e1@values,e2)
	}
	)
	
	
	setMethod("Ops", signature=c("gridlayer", "gridlayer"),
	definition=function(e1,e2){
		callGeneric(e1@values,e2@values)
	}
	)
	
	# basic statistics
	setMethod("mean", signature="gridlayer", 
	definition=function(x,...){
		callGeneric(x@values,...)
	}
	)
	
	# basic statistics
	setMethod("sd", signature="gridlayer", 
	definition=function(x,na.rm=F){
		callGeneric(x@values,na.rm=na.rm)
	}
	)
	
	# basic statistics
	setMethod("summary", signature="gridlayer", 
	definition=function(object,...){
		callGeneric(object@values,...)
	}
	)
	
	# basic statistics
	setMethod("quantile", signature="gridlayer", 
	definition=function(x,...){
		callGeneric(x@values,...)
	}
	)
	
	# basic statistics
	setMethod("median", signature="gridlayer", 
	definition=function(x,na.rm=F){
		callGeneric(x@values,na.rm=na.rm)
	}
	)
	
	
}


#accession slots
{
#values
#' @exportMethod values
setMethod(	
	f="values",
	signature="gridlayer",
	definition= function(x){
		return(x@values)
	}
)
#' @exportMethod length
setMethod(	
	f="length",
	signature="gridlayer",
	definition= function(x){
		x@length
	}
)

#' @exportMethod names
setMethod(	
	f="names",
	signature="gridlayer",
	definition= function(x){
		x@names
	}
)
		

}	

#replacement of slots
{
#values
#' @exportMethod
setReplaceMethod(	
	f="values",
	signature="gridlayer",
	definition= function(x, value){
		x@values<-value
		if(length(x@values)!=x@length){
			stop("Wrong replacement length.")
		}else{
			return(x)
		}
	}
)

}

#basic subscript
#' @exportMethod subset
setMethod(
	"subset",
	signature="gridlayer",
	definition=function(x, subsetVector){
		if(is.numeric(subsetVector)){
			#add checking for lat/long subsetting
			# lat-long mode of subsetting
			potConds<-c("lamin", "lamax", "lomin", "lomax")
			if(sum(names(subsetVector)%in%potConds)>0){
				#if it contains an unitelligible names
				if(sum(!names(subsetVector)%in%potConds)>0) 
					warning("Some subscript condition names were not recognized.")
				
				
				#in case you want something at the dateline
				normal <- T
				if(sum(c("lomax", "lomin")%in%names(subsetVector))==2){
					if(subsetVector["lomin"]>subsetVector["lomax"]){
						normal<- F
					}
				}
				
				#get the facecenters
				actGrid<-get(x@grid)
				pol <- CarToPol(actGrid@faceCenters, norad=T, origin=actGrid@center)
				
				boolSelect<-rep(T, nrow(pol))
				
				#longitude
				if(normal){
					#minimum longitude condition
					if("lomin"%in%names(subsetVector)){
						boolSelect <- boolSelect & pol[,1]>=subsetVector["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subsetVector)){
						boolSelect <- boolSelect & pol[,1]<=subsetVector["lomax"]
					}
				}else{
					#minimum longitude condition
					if("lomin"%in%names(subsetVector)){
						boolSelect <- boolSelect & pol[,1]>=subsetVector["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subsetVector)){
						boolSelect <- boolSelect | pol[,1]<=subsetVector["lomax"]
					}
				
				}
				
				#minimum latitude condition
				if("lamin"%in%names(subsetVector)){
					boolSelect <- boolSelect & pol[,2]>=subsetVector["lamin"]
				}
				
				#minimum latitude condition
				if("lamax"%in%names(subsetVector)){
					boolSelect <- boolSelect & pol[,2]<=subsetVector["lamax"]
				}
				
				subsetVector<-rownames(actGrid@faceCenters)[boolSelect]
				# control will pass over to the subsetting by facenames

			}else{
			
			# index subsetting
				y<-x
				y@names<-y@names[subsetVector]
				y@values<-y@values[subsetVector]
				y@length<-length(y@values)
			}
		}
		if(is.character(subsetVector)){
			if(sum(subsetVector%in%x@names)==length(subsetVector)){
				y<-x
				y@names<-subsetVector
				y@values<-y@values[x@names%in%subsetVector]
				y@length<-length(y@values)
			}
		
		}
		
		return(y)
		
	}
)	

#subsetting for layers
#' @exportMethod "["
setMethod(
	"[",
	signature=c("gridlayer","numeric", "missing"),
	definition=function(x,i,j,..., drop=T){
		subset(x, i)
	
	}
)

#' @exportMethod "["
setMethod(
	"[",
	signature=c("gridlayer","character", "missing"),
	definition=function(x,i,j,..., drop=T){
		subset(x, i)
	
	}
)

#' @exportMethod "["
setMethod(
	"[",
	signature=c("gridlayer","Extent", "missing"),
	definition=function(x,i,j,..., drop=T){
		#check the extent object
		
		actGrid <- get(x@grid)
		pol <- CarToPol(actGrid@faceCenters, origin=gridObj@center)
		
		boolLong<-pol[,1]>=i@xmin & pol[,1]<=i@xmax
		boolLat<-pol[,2]>=i@ymin & pol[,2]<=i@ymax
		
		nm<-rownames(pol)[boolLong & boolLat]
	
	
		subset(x, nm)
	
	}
)

#' @exportMethod "[<-"
setReplaceMethod(
	"[",
	signature="gridlayer",
	definition=function(x,i,j,..., value){
		y<-x
		#named vector replacement
		if(length(names(value))>0 & missing(i)){
			if(sum(names(value)%in%y@names)==length(value)){
				u<-y@values
				names(u)<-y@names
				u[names(value)]<-value
				y@values<-u
			}
		}else{
		#numeric
			if(is.numeric(i)){
				actGrid<-get(x@grid)
				
				subGrid<-subset(actGrid,i)
				i<-rownames(subGrid@faces)
			}
			if(is.character(i)){
				if(sum(i%in%y@names)==length(i)){
					u<-y@values
					names(u)<-y@names
					u[i]<-value
					y@values<-u
				}else{
					stop("Invalid character subscript.")
				}
			}
			if(is.logical(i)){
				y@values[i]<-value
			}
		}
		
		return(y)
	
	}
)



#2. inheriting classes
{

#facelayer
#'Container for data storage using the faces on icosahedral grid
#'
#'@name facelayer
#'
#'@rdname facelayer-class
#'
#'@exportClass facelayer
facelayer <- setClass(
	#name
	"facelayer",
	contains="gridlayer"
) 

#' Constructor of a \code{facelayer} object
#' 
#' This function will create \code{facelayer} linked to a \code{trigrid} or \code{hexagrid} object
#' 
#' The grids themselves are scaffolds for the assigned data. The data themselves are stored in containers which are linked to the the grids.
#' 
#' @param gridObj A \code{hexagrid} or \code{trigrid} object.
#' 
#' @param value The \code{facelayer} will be initialized with these values/this value
#' @name facelayer  
#' @examples
#' 	g <- trigrid(c(4,4))
#' 	fl <- facelayer(g, 1:length(g))
#' 	faces3d(fl)
#' @exportClass facelayer
setMethod("initialize", signature = "facelayer",
	definition = function(.Object, gridObj, value=NA){
		.Object@grid <- deparse(substitute(gridObj))
		.Object@tesselation <- gridObj@tesselation
		nam<-class(gridObj)
		names(nam)<-NULL
		.Object@gridclass <- nam
		.Object@names <- rownames(gridObj@faces)
		.Object@length <- length(.Object@names)
		if(length(value)==1){
			.Object@values <- rep(value, .Object@length)
		}else{
			if(length(value)==.Object@length){
				.Object@values <- value
			}else{
				stop("Length of input values does not equal facelayer length.")
			}

		}
	
		return(.Object)
	}
	
)

# defining an edgelayer is superflous!!!!!	
##edgelayer
#	#class definition
#	edgelayer <- setClass(
#		#name
#		"edgelayer",
#		contains="gridlayer"
#	) 
#	
#	setMethod("initialize", signature = "edgelayer",
#		definition = function(.Object, gridObj){
#			.Object@grid <- deparse(substitute(gridObj))
#			.Object@names <- rownames(gridObj@edges)
#			.Object@length <- length(.Object@names)
#			.Object@values <- rep(NA, .Object@length)
#			return(.Object)
#		}
#		
#	)

#pointlayer
	#class definition
	pointlayer <- setClass(
		#name
		"pointlayer",
		contains="gridlayer"
	) 
	
	setMethod("initialize", signature = "pointlayer",
		definition = function(.Object, gridObj){
			.Object@grid <- deparse(substitute(gridObj))
			.Object@names <- rownames(gridObj@vertices)
			.Object@length <- length(.Object@names)
			.Object@values <- rep(NA, .Object@length)
			return(.Object)
		}
		
	)
}


#' @rdname vertices-methods
#' @exportMethod vertices
setMethod(	
	f="vertices",
	signature="facelayer",
	definition= function(x, output="polar"){
		actGrid <- get(x@grid)
		if(output=="polar"){
			return(CarToPol(actGrid@vertices))
		
		}else{
			return(actGrid@vertices)
		}
	}
)

#' @rdname faces-methods
#' @exportMethod faces
setMethod(	
	f="edges",
	signature="facelayer",
	definition= function(x){
		actGrid<-get(x@grid)
		return(actGrid@edges)
	}
)

#' @rdname faces-methods
#' @exportMethod faces
setMethod(	
	f="faces",
	signature="facelayer",
	definition= function(x){
		actGrid<-get(x@grid)
		return(actGrid@faces)
	}
)



#' 3d plotting of a facelayer of an icosahedral grid or its subset
#'
#' The function is built on the openGL renderer of the R package \code{rgl}. The default plotting window size is 800x800 pixels. In case you want to override this, please
#' use the function with 'defaultPar3d=FALSE' after running 'par3d(windowRect=<>)'. 
#'  
#' @param x The \code{facelayer} object to be plotted.
#' 
#' @param type A character value specifying the part of the grid to be plotted by the call of the function. 
#' \code{"l"} plots the grid lines (only when frame=F). 
#' \code{"f"} draws the grid faces.
#' 
#' @param sphere Defaults to NULL, adding a central white sphere to the plot. Assigning a numeric value will draw a new sphere with the given radius,
#'		\code{FALSE} does not plot the sphere. 
#' @param defaultPar3d Logical value, whether the default settings for par3d() are to be used (windowRect = c(50, 60, 800, 800), zoom=0.8).
#' @param guides If set to TRUE the guides3d() function will be run with col="green" and default settings.
#' @param frame If set to TRUE the grid line structure will be plotted.
#' 
#' @param ... Further graphical parameters passed to (see \code{\link[rgl]{plot3d}}).
#' 
#' @exportMethod plot3d
#' @rdname plot3d-methods
# ' @aliases plot3d, facelayer-method
setMethod(
	"plot3d",
	signature="facelayer",
	definition=function(x,type="f",frame=T, guides=T, defaultPar3d=T, ...){
	
		# default par3d options
		if(defaultPar3d){
			par3d(windowRect = c(50, 60, 800, 800), zoom=0.8)
		}
			
		actGrid  <- get(x@grid)
		checkLinkedGrid(actGrid, x)
			
		#do not allow arguments to pass through!
		if(frame==T){
			plot3d(actGrid, guides=guides, col="gray50")
		}else{
			plot3d(actGrid, type="n", guides=guides)
			
			#boundaries
			if(type=="l"){
				lines3d(x,...)
		
			}
		}
		if(type=="f"){
			faces3d(x,specular="black",...)
		}
		
		#add additional types of plotting to this method
		#no plotting
		if(type=="n"){
		}
		
	
	}
)

#' @exportMethod faces3d
#' @rdname faces3d-methods
# ' @aliases faces3d, facelayer-method
setMethod(	
	f="faces3d",
	signature="facelayer",
	definition= function(x,col="red", varName="",...){
		# extract the grid that needs to be plotted:
		actGrid  <- get(x@grid)
	#	checkLinkedGrid(actGrid, x)
		
		#check whether the  grid is actually updated
		if(sum(x@names%in%rownames(actGrid@faces))!=length(x)) 
		stop("The facenames in thelinked grid does not match the facelayer object.")
		
		#when the valuues are logical
		#FALSEs do not plot; NAs do not plot, TRUEs plot
		
		# if the grid is numerical and it has only one value, make it logical
		if(class(x@values)%in%c("integer","double", "numeric")){
			if(length(unique(x@values[!is.na(x@values)]))==1){
				x@values<-as.logical(x@values)
			}
			
		}
		if(is.logical(x@values)){
			#just add NAs where the values are 0
			x@values[x@values==F]<-NA
		}
		
		#if the number of values does not match the grid face no
		boolPresent1<-rep(T,nrow(actGrid@faces))
		if(length(x)!=nrow(actGrid@faces)){
			boolPresent1<-rownames(actGrid@faces)%in%x@names
			actGrid<-subset(actGrid, rownames(actGrid@faces)[boolPresent1])
		}
		
		# in case there are NAs, do a subsetting before going on
		# rgl does not understand col=NA as omission of plotting
		if(sum(is.na(x@values))>0){
			# select only the faces that are available
			boolPresent<-!is.na(x@values)
			#1. the values
			x@values<-x@values[boolPresent]
			#2. the names too
			x@names<- x@names[boolPresent]
			#3. number
			x@length <- sum(boolPresent)
			
		#	#do a pseudo subsetting!
		#	tempFacesLog<-rep(F, length(actGrid@skeleton$aF))
		#	#what should not be removed
		#	tempFacesLog[actGrid@skeleton$offsetF+actGrid@skeleton$uiF[which(names(actGrid@skeleton$uiF)%in%x@names)]] <- TRUE
		#	#remove everthing but that
		#	actGrid@skeleton$aF[!tempFacesLog]<- FALSE
		
		
			actGrid<-subset(actGrid, x@names) # the real subsetting
			
		}
		#when the values are logical
		if(class(x@values)=="logical"){
			#set default color value
			faces3d(actGrid,col=col,...)
		}
		
		# when  numerical values are added to the facelayer object, do a heatmap!
		if(class(x@values)%in%c("integer","double", "numeric")){
			
			#do a heatmap!
			#create aramp
			#the color vector will control the heatmap
			if(length(col)==1){
				if(col=="red"){
#					col<-c("red","orange","yellow", "white")
				#	cols <- rev(heat.colors(length(x)+30))[31:(30+length(x))]
					cols <- rev(heat.colors(length(x)))
					
				}else{
					
					if(length(col)==1){
						stop("You hace specified only one color.")
					}
				
				}
			} else{
			#do a heatmap!
				ramp<-colorRampPalette(col, bias=2, space="Lab")
				cols<-ramp(length(x))
			}
			
			#minimum value assigned to the smallest
				minimum<- min(x@values)
			#this should be the first color of the rmap
				trans<-x@values-minimum
			#scale so the maximum value is the last color	
				newMax<-max(trans)
				trans2<-trans*((length(cols)-1)/(newMax))
				trans2<-trans2+1
				trans2<-round(trans2)
					
			# this is the ui sequence	
			faceColors<-cols[trans2]
			
			if(class(actGrid)=="trigrid"){
				
				#in the inner sequence
				#create a source vector as if it was complete
					faceColors2<-rep(NA, length(actGrid@skeleton$uiF))
					names(faceColors2)<-paste("F", 1:length(faceColors2), sep="")
					faceColors2[names(x)]<-faceColors
				
				#order them
					faceColors3<-rep(NA, length(faceColors2))
					faceColors3[actGrid@skeleton$uiF]<-faceColors2
				
				#and get rid of the NAs
				faceColors3<-faceColors3[!is.na(faceColors3)]
			
				
			}
			if(class(actGrid)=="hexagrid"){
				
				tu <- as.numeric(t(actGrid@skeleton$uiF[names(x),]))
				
				empty<-rep(NA, nrow(actGrid@skeleton$f))
				
				fc<-rep(faceColors, each=12)
				
				empty[tu[!is.na(tu)]] <-fc[!is.na(tu)]
				
				noNA<-empty[as.logical(actGrid@skeleton$aSF)]
			
			###	
				# get the subfaces where there is information
			#	f<-as.data.frame(actGrid@skeleton$f[as.logical(actGrid@skeleton$aSF),1:3])
				
				#which outer faces do the subfaces belong?
				aas<- actGrid@skeleton$aSF[as.logical(actGrid@skeleton$aSF)]
				
				#create a vector fro all the total colors (as if the grid was full)
				totCol<-rep(NA,nrow(actGrid@skeleton$uiF))
				names(totCol) <- paste("F", 1:length(totCol), sep="")
				
				# insert the information
				totCol[names(x)]<-faceColors
				
				#reorder the colors to the subfaces
				faceColors3<-totCol[aas]
				
				
			#	
			#	temp<-cbind(f, newCol, stringsAsFactors=F)
			#
			#	temp2<-temp[order(temp[,1]),]
			#	temp2<-unique(temp2)
				
				
				
			}
			faces3d(actGrid,col=rep(faceColors3, each=3),...)
			
			
		# numeric heatmap!			
			# increase the resolution when you plot the legend
			currentset<-par3d("windowRect")
			currentset2<-currentset
			currentset2[3]<-currentset[3]*1.5
			currentset2[4]<-currentset[4]*1.5
			
			
			# double the resolution
			par3d(windowRect=currentset2)
			# plot the background
			bgplot3d(
				# turn off the graphical parameters warning bullshit
				suppressWarnings(
					heatMapLegend(cols,minVal=min(x@values), maxVal=max(x@values),...)
				)
			)
				
			par3d(windowRect=currentset)

	
		}
		
		#when all the values are colors
		#plot faces as 
		if(class(x@values)=="character" & sum(x@values%in%colors())==x@length){
			faces3d(actGrid, col=x@values, plot="faces",...)
			
		}
		
		# when the values are text | they are not colors
		if(class(x@values)=="character" & !sum(x@values%in%colors())==x@length){
			# state the labels in 3d on the face (using the centers of the faces)
			colorAll <- grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]
			active<-factor(x@values)
			if(length(levels(active))>length(colorAll)){
				cols<-sample(colorAll, length(levels(active)), replace=T)
			}else{
				cols<-sample(colorAll, length(levels(active)), replace=F)
			}
			
			faceColors<-cols[as.numeric(active)]
			
			if(class(actGrid)=="trigrid"){
				
				#in the inner sequence
				#create a source vector as if it was complete
					faceColors2<-rep(NA, length(actGrid@skeleton$uiF))
					names(faceColors2)<-paste("F", 1:length(faceColors2), sep="")
					faceColors2[names(x)]<-faceColors
				
				#order them
					faceColors3<-rep(NA, length(faceColors2))
					faceColors3[actGrid@skeleton$uiF]<-faceColors2
				
				#and get rid of the NAs
				faceColors3<-faceColors3[!is.na(faceColors3)]
			
				
			}
			if(class(actGrid)=="hexagrid"){
				
				tu <- as.numeric(t(actGrid@skeleton$uiF[names(x),]))
				
				empty<-rep(NA, nrow(actGrid@skeleton$f))
				
				fc<-rep(faceColors, each=12)
				
				empty[tu[!is.na(tu)]] <-fc[!is.na(tu)]
				
				noNA<-empty[as.logical(actGrid@skeleton$aSF)]
			
			###	
				# get the subfaces where there is information
			#	f<-as.data.frame(actGrid@skeleton$f[as.logical(actGrid@skeleton$aSF),1:3])
				
				#which outer faces do the subfaces belong?
				aas<- actGrid@skeleton$aSF[as.logical(actGrid@skeleton$aSF)]
				
				#create a vector fro all the total colors (as if the grid was full)
				totCol<-rep(NA,nrow(actGrid@skeleton$uiF))
				names(totCol) <- paste("F", 1:length(totCol), sep="")
				
				# insert the information
				totCol[names(x)]<-faceColors
				
				#reorder the colors to the subfaces
				faceColors3<-totCol[aas]
				
				
			#	
			#	temp<-cbind(f, newCol, stringsAsFactors=F)
			#
			#	temp2<-temp[order(temp[,1]),]
			#	temp2<-unique(temp2)
				
				
				
			}
			faces3d(actGrid,col=rep(faceColors3, each=3),...)
			
			
		}
		
		# when the values are factors!
		if(class(x@values)=="factor"){
			# depending on the number of levels, more color palettes might be useful
			if(length(levels(factor(x@values))) <= 7){
				faces3d(actGrid, col=rep(as.numeric(x@values),each=3), ...)
			
			}
		}	
	#	legend3d()
	}
)

# google: modify passing arguments

	
setMethod(
	"faces3d",
	signature="pointlayer",
	definition=function(x,...){
		
		# extract the grid that needs to be plotted:
		actGrid  <- get(x@grid)
		
		checkLinkedGrid(actGrid, x)
		
		#check whether the  grid is actually updated
		if(nrow(actGrid@vertices)!=length(x)) stop("The linked grid does not match the facelayer object.")
		
		#when the valuues are logical
		#FALSEs do not plot; NAs do not plot, TRUEs plot
		
		if(is.logical(x@values)){
			#just add NAs where the values are 0
			x@values[x@values==F]<-NA
		}
		
		# in case there are NAs, do a subsetting before going on
		# rgl does not understand col=NA as omission of plotting
		if(sum(is.na(x@values))>0){
			# select only the faces that are available
			boolPresent<-!is.na(x@values)
			#1. the values
			x@values<-x@values[boolPresent]
			#2. the names too
			x@names<- x@names[boolPresent]
			#3. number
			x@length <- sum(boolPresent)
			actGrid<-subset(actGrid, x@names)
			
		}
		#when the values are logical
		if(class(x@values)=="logical"){
			#set default color value
			faces3d(actGrid,...)
		}
		
		# when  numerical values are added to the facelayer object, do a heatmap!
		if(class(x@values)%in%c("integer","double", "numeric")){
			
			#do a heatmap!
			#create aramp
			#the color vector will control the heatmap
			if(length(col)==1){
				if(is.na(col)){
					col<-c("red","orange","yellow", "white")
				}else{
					
					if(length(col)==1){
						stop("You hace specified only one color.")
					}
				
				}
			}
			#do a heatmap!
				ramp<-colorRampPalette(col, bias=2, space="Lab")
				cols<-ramp(length(x))
			#minimum value assigned to the smallest
				minimum<- min(x@values)
			#this should be the first color of the rmap
				trans<-x@values-minimum
			#scale so the maximum value is the last color	
				newMax<-max(trans)
				trans2<-trans*((length(cols)-1)/(newMax))
				trans2<-trans2+1
				trans2<-round(trans2)
					
				
			pointcolors<-cols[trans2]
			indexCols<- .Call('icosa_pointLayerColorOrder_', PACKAGE = 'icosa', f=actGrid@skeleton$faces)
			# the points are repeated as in faces
			
			faces3d(actGrid,col=pointcolors[indexCols+1],...)
		}
	
	}
)	

#meaningless? - ask Wolfgang
setMethod(
	"lines3d", 
	signature="facelayer",
	definition=function(x,...){
	# extract the grid that needs to be plotted:
		actGrid  <- get(x@grid)
		
		checkLinkedGrid(actGrid, x)
		#check whether the  grid is actually updated
		if(nrow(actGrid@faces)!=length(x)) stop("The linked grid does not match the facelayer object.")
		
		#when the valuues are logical
		#FALSEs do not plot; NAs do not plot, TRUEs plot
		
		if(is.logical(x@values)){
			#just add NAs where the values are 0
			x@values[x@values==F]<-NA
		}
		
		# in case there are NAs, do a subsetting before going on
		# rgl does not understand col=NA as omission of plotting
		if(sum(is.na(x@values))>0){
			# select only the faces that are available
			boolPresent<-!is.na(x@values)
			#1. the values
			x@values<-x@values[boolPresent]
			#2. the names too
			x@names<- x@names[boolPresent]
			#3. number
			x@length <- sum(boolPresent)
			
			#do a pseudo subsetting!
			tempEdgesLog<-rep(F, length(actGrid@skeleton$aE))
			#what should not be removed
			actGrid<-subset(actGrid, x@names) # the real subsetting
			
		}
		#when the values are logical
		if(class(x@values)=="logical"){
			#set default color value
			lines3d(actGrid,col=col,...)
		}	
	
	}
)

#' 2d plotting of a facelayer class object
#' This function will invoke the 2d plotting methods of a grid so data stored in a facelayer object can be displayed.
#'
#' The function passes arguments to the plot method of the SpatialPolygons class (€ref). In case a heatmap is plotted and the windows plotting device gets resized,
#' some misalignments can happen. If you want to use a differently sized window, use windows() to set the height and width before running the function.
#' @param x The facelayer object to be plotted.
#' @param projargs Class 'CRS', a proj4 projection method string.
#' @param frame Logical value, if TRUE the grid boundaries will be drawn with black.
#' @param col Character vector. Colors passed to a colorRampPalette() in case of the facelayer contains logical values, a single value is required (defaults to red).
#' @param border Character value specifying the color of the borders of the cells.
#' @param alpha Character value of two digits for the fill colors, in hexadecimal value between 0 and 255.
#' @rdname plot-methods
#' @exportMethod plot
setMethod(
	"plot",
	signature="facelayer",
	definition=function(x,projargs=NULL,col="red",border=NA, alpha="", frame=F,...){
		actGrid<-get(x@grid)
		checkLinkedGrid(actGrid, x)
		
		#if no @sp found
		if(suppressWarnings(is.na(actGrid@sp))){
			stop(paste("Slot @sp in the linked grid \'",x@grid, "\' is empty.", sep=""))
		}
		
		#transformation is necessary
		if(!is.null(projargs)){
			require(rgdal)
			actGrid@sp<-spTransform(actGrid@sp, projargs)
		}
		#check whether the  grid is actually updated
		if(sum(x@names%in%rownames(actGrid@faces))!=length(x)) 
		stop("The facenames in thelinked grid does not match the facelayer object.")
		
		# if the grid is numerical and it has only one value, make it logical
		if(class(x@values)%in%c("integer","double", "numeric")){
			if(length(unique(x@values[!is.na(x@values)]))==1){
				x@values<-as.logical(x@values)
			}
			
		}
		#when the valuues are logical
		#FALSEs do not plot; NAs do not plot, TRUEs plot
		
		if(is.logical(x@values)){
			#just add NAs where the values are 0
			x@values[x@values==F]<-NA
		}
		
		#if the number of values does not match the grid face no
		boolPresent1<-rep(T,nrow(actGrid@faces))
		if(length(x)!=nrow(actGrid@faces)){
			boolPresent1<-rownames(actGrid@faces)%in%x@names
		}
		actSp<-actGrid@sp[boolPresent1]
		
	
		#get rid of the NAs
		boolPresent<-rep(T,length(x))
		# in case there are NAs, do a subsetting before going on
		# rgl does not understand col=NA as omission of plotting
		if(sum(is.na(x@values))>0){
			# select only the faces that are available
			boolPresent<-!is.na(x@values) 
			#1. the values
			x@values<-x@values[boolPresent]
			#2. the names too
			x@names<- x@names[boolPresent]
			#3. number
			x@length <- sum(boolPresent)
		}
		actSp<-actSp[boolPresent]
		
		#when the values are logical
		if(class(x@values)=="logical"){
			#set default color value
			plot(actSp,col=col,border=border,...)
		}
		
		# when  numerical values are added to the facelayer object, do a heatmap!
		if(class(x@values)%in%c("integer","double", "numeric")){
			
			#do a heatmap!
			#create aramp
			#the color vector will control the heatmap
			if(length(col)==1){
				if(col=="red"){
#					col<-c("red","orange","yellow", "white")
					cols <- rev(heat.colors(length(x)+30))[31:(30+length(x))]
					cols<-substring(cols, 1,7)
				}else{
					
					if(length(col)==1){
						stop("You hace specified only one color.")
					}
				
				}
			} else{
			#do a heatmap!
				ramp<-colorRampPalette(col, bias=2, space="Lab")
				cols<-ramp(length(x))
			}
			
			#minimum value assigned to the smallest
				minimum<- min(x@values)
			#this should be the first color of the rmap
				trans<-x@values-minimum
			#scale so the maximum value is the last color	
				newMax<-max(trans)
				trans2<-trans*((length(cols)-1)/(newMax))
				trans2<-trans2+1
				trans2<-round(trans2)
					
			# this is the ui sequence	
			faceColors<-cols[trans2]
			if(is.character(border)){
				if(length(unique(border))==1){
					if(substring(border[1], 1,1)=="#"){
						border=paste(border, alpha,sep="")
					}
				
				}
			}
			faceColors<-paste(faceColors, alpha, sep="")
			# set the new margins
			
			par(mar=c(2,2,2,8))
			# plot the sp object with the given argumetns
				# get rid of some of the arguments
				addArgs<-list(...)
				
				# arguments of the heatMapLegend()
				addArgs$tick.text<-NULL
				addArgs$ticks<-NULL
				addArgs$tick.cex<-NULL
				addArgs$barWidth<-NULL
				addArgs$barHeight<-NULL
				addArgs$tickLength<-NULL
				addArgs$xBot<-NULL
	
				
				firstArgs<-list(
					x=actSp,
					col=faceColors,
					border=border
				)
					
				plotArgs<-c(firstArgs, addArgs)
				
				do.call(plot, plotArgs)
			
			#the heatmap legend
				#in case a heatmap is needed
				oldRef<-par()
				oldRef$cin<-NULL
				oldRef$cra<-NULL
				oldRef$cxy<-NULL
				oldRef$din<-NULL
				oldRef$page<-NULL
				oldRef$csi<-NULL
				
				par(usr=c(0,100,0,100))
				par(xpd=NA)
				par(mar=c(2,2,2,2))
				
				# additional argumetns to the heatmap, remove something
				addArgs<-list(...)
				addArgs$axes<-NULL
				addArgs$add<-NULL
				
				firstArgs<-list(
					cols=cols,
					minVal=min(x@values, na.rm=T),
					maxVal=max(x@values, na.rm=T),
					add=T,
					xLeft=101
				)
				
				# all the argumetns of the heatmap
				heatArgs<-c(firstArgs, addArgs)
				
				suppressWarnings(
					do.call(heatMapLegend, heatArgs)
				
				)
				par(oldRef)
				
		}
		
		# when the values are text | they are not colors
		if(class(x@values)=="character" & !sum(x@values%in%colors())==x@length){
			# state the labels in 3d on the face (using the centers of the faces)
			colorAll <- grDevices::colors()[grep('gr(a|e)y', grDevices::colors(), invert = T)]
			active<-factor(x@values)
			if(length(levels(active))>length(colorAll)){
				cols<-sample(colorAll, length(levels(active)), replace=T)
			}else{
				cols<-sample(colorAll, length(levels(active)), replace=F)
			}
			
			faceColors<-cols[as.numeric(active)]
			if(is.character(border)){
				if(length(unique(border))==1){
					if(substring(border[1], 1,1)=="#"){
						border=paste(border, alpha,sep="")
					}
				
				}
			}
			faceColors<-paste(faceColors, alpha, sep="")
		
		}
		if(class(x@values)=="character" & sum(x@values%in%colors())==x@length){
			faceColors<-paste(x@values, alpha, sep="")
		}
		
		if(class(x@values)=="character"){
		
			# plot the sp object with the given argumetns
				# get rid of some of the arguments
				addArgs<-list(...)
				
				# arguments of the heatMapLegend()
				addArgs$tick.text<-NULL
				addArgs$ticks<-NULL
				addArgs$tick.cex<-NULL
				addArgs$barWidth<-NULL
				addArgs$barHeight<-NULL
				addArgs$tickLength<-NULL
				addArgs$xBot<-NULL
	
				
				firstArgs<-list(
					x=actSp,
					col=faceColors,
					border=border
				)
					
				plotArgs<-c(firstArgs, addArgs)
				
				do.call(plot, plotArgs)
			
		}

		# when the col argument actually contains colors
		
		if(frame){
			
			plot(actSp, border="black", add=T)
			
		}
	
	
	}

)

#' @rdname gridgraph-methods
#' @exportMethod gridgraph
setMethod(
	f="gridgraph",
	signature="facelayer",
	definition=function(x,...){
		# the grid object of the facelayer
		actGrid <- get(x@grid)
		
		checkLinkedGrid(actGrid, x)
		
		# only the occupied cells should be part of the grid
		# or: where the logical values indicate absence
		if(is.logical(x@values)){
			x@values[x@values==FALSE] <- NA
		}
		
		# these will be the nodes of the graph
		nodes<- x@names[!is.na(x@values)]
		
		# subset the graph to the nodes which are indicated in the facelayer
		actGraph <- induced_subgraph(actGrid@graph, nodes)
		
		# the values of the facelayer should be also present
		if(!is.logical(x@values)){
			V(actGraph)$value <- x@values[!is.na(x@values)]
		}
		
		return(actGraph)

	}
)


#' Resampling a facelayer at different resolution
#' 
#' This function will calculate values for a different resolution grid
#' 
#' The function applies different resampling algorithms.
#' 
#' @param x a \code{facelayer} class object.
#' 
#' @param y a \code{hexagrid} or \code{trigrid} object.
#' 
#' @param method Character string stating the name of the algorithm used for resampling. 
#' 
#' @return A named numeric vector.
#' 
#' @examples
#' 	g <- trigrid(c(4,4))
#' 	fl <- facelayer(g)
#'	fl@values<-rnorm(length(fl))
#' 	h <- trigrid(4)
#'	res <- resample(fl, h)
#' 	fl2<-facelayer(h)
#'	fl2@values[] <- res
#'
#' @exportMethod resample
setMethod(
	"resample",
	signature=c("facelayer", "trigrid"),
	definition=function(x, y,method=NULL,res=5,...){
	#x:layer, y new grid
		oldGrid<-get(x@grid)
		values<-x@values
		#only if values is a numeric vector!
		if(!is.numeric(x@values)){
			
		}
		
		# do some checking immediately: upscaling or downscaling
		# downscaling
		if(length(oldGrid)>length(y)){
			downscale <- TRUE
			if(is.null(method)){
				method <- "average"
			}else{
				# perform a check of the potential resampling methods
				if(!method%in%c("average")){
					stop("Invalid downscaling method. ")
				}
			}
			
		} else {
			downscale <- FALSE
			if(is.null(method)){
				method <- "ebaa"
			}else{
				# perform a check of the potential resampling methods
				if(!method%in%c("ebaa")){
					stop("Invalid upscaling method.")
				}
			}
			
		}
		
		# do some checking
		#the two grids should have the same centers and radius
		
#		# reorder the values to the internal order of oldGrid
#		intValues<-values
#		if(class(oldGrid)=="trigrid"){
#			intValues[oldGrid@skeleton$uiF]<-values
#		}
#		
#		if(class(oldGrid)=="hexagrid"){
#			intValues<-values[oldGrid@skeleton$aF]
#		}
		
		# easier case:
		# given that downsampling occurs
		if(downscale){
			if(method=="average"){
				#oldgrids facecenters
				loc<-locate(y, oldGrid@faceCenters)
				newVals<-tapply(INDEX=loc, X=values, function(x){mean(x, na.rm=T)})
				newVals<-newVals[rownames(y@faces)]
				nVNames<-names(newVals)
				newVals<-as.numeric(newVals)
				names(newVals)<-nVNames
			}
		
		}
		
		#given that upsampling occurs
		# edge breakpoint area approximation 
		if(!downscale){
			if(method=="ebaa"){
				
				# basic algorithm
				# 1. break down every single edge of the finer, new grid using SplitArc() and produce a table with xyz coordinates
				if(class(y)=="trigrid"){
					newGridF<-y@skeleton$f[y@skeleton$f[,4]==(length(y@tesselation)-1),]
					
					# c++ function will look up produce these points
					newPoints<-.Call('icosa_ExpandEdgesByFacesTri_', PACKAGE = 'icosa', y@skeleton$v, newGridF, y@center, res)
					newPoints[,4] <- newPoints[,4]+1
					# outer order
					fNames<-names(sort(y@skeleton$uiF))
					newNames <- fNames[newPoints[,4]]
				}
				if(class(y)=="hexagrid"){
					newGridF<-y@skeleton$f[y@skeleton$f[,4]==-6,]
				
					# c++ function will look up produce these points
					newPoints<-.Call('icosa_ExpandEdgesByFacesTri_', PACKAGE = 'icosa', y@skeleton$v, newGridF, y@center, res)
					newPoints[,4] <- newPoints[,4]+1
					
					# create a proper UIF table
					tempUIF <- as.numeric(t(y@skeleton$uiF))
					names(tempUIF)<-rep(rownames(y@skeleton$uiF), each=12)
					
					# get rid of NAs
					tempUIF<-tempUIF[!is.na(tempUIF)]
					
					# outer order
					fNames<-names(sort(tempUIF))
					newNames <- fNames[newPoints[,4]]
				
				}
				
				
				# 2. look up these new coordinates in the old grid, it is not a problem if they are not found (locate produces NAs)
					oldCells<-locate(oldGrid, newPoints[,1:3])
					
					# 3. get the values from the facelayer that corresponds to these face designations
					names(x@values) <- x@names
					oldVals<-x@values[oldCells]
					
					# 4. average them out with tapply()
					newVals<-tapply(INDEX=newNames, X=oldVals, mean, na.rm=T)
				
					# 5. you have an estimation based on the approximate coverages
					nVNames<-names(newVals)
					newVals<-as.numeric(newVals)
					names(newVals)<-nVNames
				
			}
		}
		
		return(newVals)
	}
	
)




### junk and examples

#defGrid<-trigrid(c(2,2))

#	# additional things
#	
#	
#	a<-facelayer(defGrid)
#	#b<-edgelayer(defGrid)
#	c<-pointlayer(defGrid)
#	
#	
#	values(a)<-sample(c(T,F),length(a), replace=T)	
#	#
#	
#	resample(layerObj, newGrid, method)



