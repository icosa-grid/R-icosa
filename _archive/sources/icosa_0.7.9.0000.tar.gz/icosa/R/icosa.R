#' Global triangular and hexa-pentagonal grids based on tesselated icosahedra
#' 
#' The \bold{icosa} package provides tools to aggregate and analyze geographic data
#' using grids based on tesselated icosahedra. 
#' 
#' Instead of using 2d projections, the package uses the original 3d space for all calculations.
#'
#' @section Author Package was developed by Ádám T. Kocsis
#' @docType package
#' @examples
#' # Create a triangular grid
#' tri <- trigrid(c(2,2))
#' @name icosa
#' @useDynLib icosa
#' @importFrom Rcpp sourceCpp
#' @importFrom rgl plot3d
#' @importFrom sp coordinates
#' @importFrom rgl lines3d
#' @importFrom raster subset
#' @importFrom raster rotate
#' @importFrom raster values
NULL

#the objects ---------
