#package namespace variables
	origin<-c(0,0,0)
	authRadius<-6371.0071810 # authalic radius (R2) based on Moritz, 1980
	meanRadius<-6371.0087714 # mean radius (R1) based on Mortiz, 1980
	volRadius <-6371.0007900 # radius of sphere of same volume
	
	
# S4 class definitions
# the core class! -  no need to export
obj3d <- setClass(
	#class
	"obj3d",
	
	slots=c(
		vertices = "matrix",
		faces = "matrix",
		edges = "matrix",
		center = "numeric",
		length = "numeric"
	)
)

setMethod(	
	f="show",
	signature="obj3d",
	definition= function(object){
		cat(paste("A/An ", class(object), " object with ", 
			object@length[1], " vertices, ",
			object@length[2], " edges and ",
			object@length[3], " faces.\n",
			sep=""))
		if(class(object)%in% c("trigrid", "hexagrid")){
		
		}
		cat("Use plot3d() to see a 3d render.\n")
	}
)

setMethod(	
	f="length",
	signature="obj3d",
	definition= function(x){
		return(x@length[3])
	}
)

#' The vertices of a 3d object
#'
#' @name vertices
#' @rdname vertices-methods
#' @exportMethod vertices
setGeneric(
	name="vertices",
	def=function(x,...){
		standardGeneric("vertices")
	}
)

#' @rdname vertices-methods
#' @aliases vertices, obj3d-methods
#' @exportMethod vertices
setMethod(	
	f="vertices",
	signature="obj3d",
	definition= function(x){
		return(x@vertices)
	}
)

#' The faces of a 3d object
#'
#' @name faces
#' @rdname faces-methods
#' @exportMethod faces
setGeneric(
	name="faces",
	def=function(x,...){
		standardGeneric("faces")
	}
)

#' @rdname faces-methods
#' @aliases faces, obj3d-methods
#' @exportMethod faces
setMethod(	
	f="faces",
	signature="obj3d",
	definition= function(x){
		return(x@faces)
	}
)

#' The edges of a 3d object
#'
#' @name edges
#' @rdname edges-methods
#' @exportMethod edges
setGeneric(
	name="edges",
	def=function(x,...){
		standardGeneric("edges")
	}
)

#' @rdname edges-methods
#' @aliases edges, obj3d-methods
#' @exportMethod edges
setMethod(	
	f="edges",
	signature="obj3d",
	definition= function(x){
		return(x@edges)
	}
)


#the icosahedron
icosahedron <- setClass(
	"icosahedron",
	
	slots = c(
		edgeLength = "numeric",
		skeleton = "list",
		r = "numeric",
		sp="ANY"
	),
	
	contain="obj3d"
)

#constructor of icosahedron
setMethod(
	"initialize",
	signature = "icosahedron",
	definition = function (.Object, r=F,a=F){
		# calculate the missing thing
		if(missing(a))
		{
			.Object@r<-r
			.Object@edgeLength<-r/(sin(2*pi/5))
		}
		if(missing(r))
		{
			.Object@edgeLength<-a
			.Object@r<-a*(sin(2*pi/5))
		}
		
		phi<-0.5*(1+sqrt(5))
		
		P1<-c(0,1,phi)/2
		P2<-c(0,1,-phi)/2
		P3<-c(0,-1,phi)/2
		P4<-c(0,-1,-phi)/2
		
		P5<-c(1,phi,0)/2
		P6<-c(1,-phi,0)/2
		P7<-c(-1,phi,0)/2
		P8<-c(-1,-phi,0)/2
		
		P9<-c(phi,0,1)/2
		P10<-c(phi,0,-1)/2
		P11<-c(-phi,0,1)/2
		P12<-c(-phi,0,-1)/2
		
		vertices<-rbind(P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12)*.Object@edgeLength
		
		#maximum precision achieved by rotation
		rotVal<-0.55357435889704526002
		vertices<-t(apply(vertices, 1, rotateOnePoint, angles=c(rotVal,0,0), origin=c(0,0,0)))

		colnames(vertices)<-c("x","y","z")
		
		#the edges
		edges<-NULL
		for(i in 1:nrow(vertices))
		{
			for (j in 1:nrow(vertices))
			{
				A<-unlist(vertices[i,])
				B<-unlist(vertices[j,])
				mTwo<-matrix(c(A,B),ncol=3, byrow=T)
				d<-dist(mTwo)
				if(round(d-.Object@edgeLength,10)==0)
				{
					E<-c(rownames(vertices)[i], rownames(vertices)[j])
					E<-sort(E)
					edges<-rbind(edges, E)
				}
			
			
			
			}
			
		}
		edges<-unique(edges)
		rownames(edges)<-paste("E", 1:nrow(edges), sep=(""))
		
		faces<-NULL
		#the faces
		for(i in 1:nrow(edges))
		{
			actEdge<-unlist(edges[i,])
			
			#P1
			b1<-edges[,1]%in%actEdge[1] | edges[,2]%in%actEdge[1]
			
			u1<-unique(c(edges[b1,1], edges[b1,2]))
			
			#P3
			b2<-edges[,1]%in%actEdge[2] | edges[,2]%in%actEdge[2]
			
			u2<-unique(c(edges[b2,1], edges[b2,2]))
			#double faces
				chDoub<-u1[u1%in%u2]
			#new points
				chNew<-chDoub[!chDoub%in%actEdge]
			
			#new lines in the faces
			#the first new point
			F<-sort(c(actEdge, chNew[1]))
			faces<-rbind(faces,F)
			
			#the second new point
			F<-sort(c(actEdge, chNew[2]))
			faces<-rbind(faces,F)
			
				
		}
		faces<-unique(faces)
		rownames(faces)<-paste("F",1:nrow(faces), sep="")
		
		.Object@faces<-faces
		.Object@edges<-edges
		.Object@vertices<-vertices
		.Object@center <- c(0,0,0)
		.Object@length<- c(
			"vertices"=nrow(vertices),
			"edges"=nrow(edges),
			"faces"=nrow(faces))
			
		# the skeleton:
			#vertices
			v<-vertices
			rownames(v)<-NULL
			
			#faces
			f<-matrix(NA, nrow=20,ncol=5)
			fTemp<-as.numeric(unlist(lapply(strsplit(as.character(faces),"P"), function(x){x[2]})))
			f[,1:3]<-matrix(fTemp, ncol=3)-1
			f[,4] <- rep(-1,nrow(f))
			f[,5] <- rep(-1,nrow(f))
		
	
		.Object@skeleton<-list(v=v, f=f)
		
		return(.Object)
	}
)

#	ic<-icosahedron(r=6371)
#
#	# testing the icosahedron plot
#		icosa<-icosahedron(r=authRadius)
#		
#		# test plot
#		points3d(icosa@vertices)
#		text3d(icosa@vertices, texts=rownames(icosa@vertices))
#	
#		# plot edges
#		for(i in 1:nrow(icosa@edges)){
#			lines3d(x=icosa@vertices[icosa@edges[i,],1], y=icosa@vertices[icosa@edges[i,],2],icosa@vertices[icosa@edges[i,],3])
#		}
#		
#		# plot faces
#		for(i in 1:nrow(icosa@faces)){
#			triangles3d(icosa@vertices[icosa@faces[i,],1], icosa@vertices[icosa@faces[i,],2], icosa@vertices[icosa@faces[i,],3], col=paste("gray", 20+i*2, sep=""))
#		}





#' Creation of a triangular tesselated icosahedral grid
#' 
#' \code{trigri} creates either a triangular  grid based on the
#'    tesselation of an icosahedron.
#'
#' The grid structure functions as a frame for data graining, plotting and
#'	calculations. Data can be stored in layers that are linked to the grid object. In the current version only the 
#'	\code{facelayer} class is implemented which allows the user to render data to the cells
#'	of the grid which are called faces. 
#'	The grid 'user interface' is made up of three primary tables: the \code{@vertices} table for the coordinates of the vertice,
#'	the \code{faces} and the \code{edges} table that contain which vertices form which faces and edges respectively.
#'	In these tables the faces and vertices are sorted to form spirals that go down from the north pole in a counter-clockwise
#'	direction. In case grid subsetting is performed these tables get truncated.
#'	
#'	At finer resolutions, the large number of spatial elements render all calculations very resource demanding and slow, 
#'	therefore the hierarchical structure created during the tesselation procedure is retained for efficient implementations.
#'	These data are stored in a list in the slot \code{@skeleton} and are 0-indexed integer tables for Rccp-based functions. \code{$v} 
#'	stores vertex, \code{$f} the edge, and \code{$e} contains the edge data for plotting and calculations. In these tables
#'	the original hierarchy based orderings of the units are retained, during subsetting, additional vectors are used to indicate
#'	deactivation of these units. Any sort of meddling with the @skeleton object will lead to unexpected behavior.
#'	
#' @slot vertices Matrix of the vertex coordinates.
#'
#' @slot faces Matrix of the verticies forming the faces
#'
#' @slot edges Matrix of the vertices forming the edges.
#'
#'	@slot tesselation contains the tesselation vector.
#'
#'	@slot orientation contains the grid orientation in xyz 3d space, values in radian.
#'
#'	@slot center is the xyz coordinates of the grids origin/center.
#'
#'	@slot div vector contains the number of faces that a single face of the previous tesselation level is decomposed to.
#'
#'	@slot faceCenters contains the xyz coordinates of the centers of the faces on the surface of the sphere.	
#'
#'
#' @param tesselation An integer vector with the tesselation values. Each number
#'    describes the number of new edges replacing one original edge. Multiple series of tesselations
#' 	  are possible this way. The total tesselation is the product of the tesselation vector. 
#'	  Higher values result in more uniform cell sizes, but the larger number of tesselation series,
#'	  increases the speed of lookup functions
#'
#' @rdname trigrid-class
#' @name trigrid
#'
#' @return A triangular grid object, with class \code{trigrid}.
#' @examples
#' 	g <- trigrid(c(8))
#' 	g1 <- trigrid(c(2,3,4,5))
#' @exportClass trigrid
trigrid<-setClass(
	"trigrid",
	contain="icosahedron",
	slots=c(
		tesselation="numeric",
		div="numeric",
		faceCenters="matrix",
		orientation="numeric",
		belts="numeric",
		proj4string="CRS"
	)
)



#' @name trigrid
#' @rdname trigrid-class
#' @exportMethod trigrid
setMethod(
	"initialize",
	signature="trigrid",
	definition=function(.Object, tesselation=1, sp=F, radius=authRadius){
		
		# trial variables
	#	tesselation<-c(2,2,2,2)
	#	authRadius<-6371
	#	degree<-1
	#	fa<-4
		##check the tesselation vector
		if(!sum(tesselation%%1)==0 | !is.numeric(tesselation))
		{
			stop("Invalid tesselation vector. Please enter a vector of integers only.")
		}
		if(prod(tesselation)==0){
			stop("Invalid tesselation vector. Please enter a vector of integers without 0s.")
		}
		

		# create a basic icosahedron
			icosa<-icosahedron(r=radius)
		
			# the final trigrid object
			.Object@tesselation <-tesselation
			.Object@r <- radius
			.Object@center <- icosa@center
			
			# add the CRS for spatial transformations
			#supress scientific notation
			options(scipen=999)
			.Object@proj4string <- CRS(paste("+proj=longlat +a=", round(radius*1000), " +b=", round(radius*1000), sep=""))
			options(scipen=0)
			
		# extract the skeleton	
			f=icosa@skeleton$f
			v=icosa@skeleton$v
		
		# in case a tesselation is happening
		if(prod(tesselation)>1){
			# invoke the c++ function to create a grid
			newGrid<-.Call('icosa_IcosahedronTesselation_', 
				PACKAGE = 'icosa', 
				v,
				f, 
				tesselation, 
				icosa@center)
		}else{
			newGrid <-list(f=f, v=v)
		}
			
		
		# additional data
			# the divisions
			div <- c(20, tesselation^2)
			
			# in case of the icosahedron
			if(prod(tesselation)==1){
				div<-20
			}
			
			.Object@div <- div
	
		# calculate the edges
			# boolean variables for the subsetting
			if(prod(tesselation)>1){
				aF <- newGrid$f[,4]==(length(tesselation)-1)
			# for special case of the icosahedron
			}else{
				aF <- newGrid$f[,4]==-1
			}
			offSet<-min(which(aF))-1
			
			aV <- rep(T, nrow(newGrid$v))
		
			faces<-subset(newGrid$f, aF)[,1:3]
			# edges
			e<-unique(.Call('icosa_expandFacesToEdges_', PACKAGE = 'icosa', faces))
			aE <- rep(T, nrow(e))
			# the neighbours of the faces
			n<-.Call('icosa_AllNeighboursTri_', PACKAGE = 'icosa', newGrid$f[,1:3], div)
			
		
		# the R grid UI
		# vertices
			vertices<- newGrid$v
			colnames(vertices) <- c("x","y","z")
			
		
		# the centers of the triangles
			faceCenters<-.Call('icosa_allTriangleCenters_', PACKAGE = 'icosa', newGrid$v, faces, icosa@center)
			colnames(faceCenters)<-c("x","y","z")
			
	
		#ordering the face and vertex data
			#vertex at the very north
				topVert<- which(max(vertices[,3])==vertices[,3])-1
			
			#top five faces
				firstFiveFace<-order(faceCenters[,3], decreasing=T)[1:5]
				#ordered by longitude
				longOrd<-order(CarToPol(faceCenters[firstFiveFace,], norad=T, origin=icosa@center)[,"long"])
				startFaces<-firstFiveFace[longOrd]
			
			#starting vertices
				startF<-faces[startFaces,]
				
				startVert<-numeric(6)
				startVert[1]<-topVert
				startVert[2]<-startF[1,c(F,startF[1,2:3]%in%startF[5,2:3])]
				
				for(i in 1:4){
					startVert[i+2]<-startF[i,!startF[i,]%in%c(startVert)]
				}
				
			# arguments for the ordering function	
				nBelts<-prod(tesselation)*3
				# in case the  thing is an icosahedron
				
				nV<-nrow(vertices)
				startFaces<-startFaces-1
			
			#call
				ordering<-.Call('icosa_orderTriGrid_', PACKAGE = 'icosa', faces, n, startFaces, startVert, nBelts, nV)
			
			# the belts
				# where do the belts start
				beltStartsAndEnd<-c(ordering$belts+1, nrow(faces))
				
				#empty container
				belts<-rep(NA, nrow(faces))
				
				#for every belt
				for(i in 1:(length(beltStartsAndEnd)-1)){
					
					if(i<(length(beltStartsAndEnd)-1)){
						actInd<-beltStartsAndEnd[i]:(beltStartsAndEnd[i+1]-1)
					}else{
						actInd<-beltStartsAndEnd[i]:(beltStartsAndEnd[i+1])
					}
					#store
					belts[actInd]<-i
				}

				.Object@belts<-belts
			#output formatting (R indices)
				#UI-skeleton translation
				faceOrder<-ordering$faceOrder+1 # good
				names(faceOrder)<-paste("F", 1:nrow(faces), sep="") #good
				
				vertexOrder<-ordering$vertexOrder+1
				names(vertexOrder)<-paste("P", 1:nrow(vertices), sep="") #good
				
				#skeleton-UI translation (R indicies)
				faceInvertOrder<-rep(0, length(faceOrder))
				faceInvertOrder[faceOrder]<-1:length(faceOrder)
				
				vertexInvertOrder<-rep(0, length(vertexOrder))
				vertexInvertOrder[vertexOrder]<-1:length(vertexOrder)
				
				
				aF[aF]<-faceInvertOrder #not good
				aV[aV]<-vertexInvertOrder#not good
				
			
			# the skeleton
				.Object@skeleton <- list(v=newGrid$v,aV=aV, uiV=vertexOrder, e=e, aE=aE,  f=newGrid$f, aF=aF, uiF=faceOrder, n=n, offsetF=offSet)
#				.Object@skeleton <- list(v=newGrid$v,aV=aV, e=e, aE=aE,  f=newGrid$f, aF=aF)
			
			#using the output to order
			vertices<-vertices[vertexOrder,]
			rownames(vertices) <- paste("P",1:nrow(vertices) ,sep="")
		
			# the edges (outer ordering)
			tempE<-aV[as.numeric(e+1)]
			
			edges<-matrix(paste("P",tempE, sep=""), ncol=2)
			rownames(edges)<-paste("E", 1:nrow(edges), sep="")
			
			# the faces
			faces<-faces[faceOrder,]
			#translate the vertex information!
			facesNum<-as.numeric(faces)+1
			faces2<-aV[facesNum]
			
			faces<-matrix(paste("P",faces2, sep=""), ncol=3)
			rownames(faces)<-paste("F", 1:nrow(faces), sep="")
		
			#the faceCenters
			faceCenters<-faceCenters[faceOrder,]
			rownames(faceCenters)<-paste("F", 1:nrow(faceCenters), sep="")
			
			#add to the object
			.Object@faces <- faces
			.Object@vertices <- vertices
			.Object@edges <- edges
			.Object@faceCenters <- faceCenters
		
		#length attribute
		.Object@length<- c(
			"vertices"=nrow(.Object@vertices),
			"edges"=nrow(.Object@edges),
			"faces"=nrow(.Object@faces))
			
		.Object@edgeLength <- c(
			mean(.Call('icosa_edges_', PACKAGE = 'icosa', newGrid$v, e, icosa@center, 1)),
			mean(.Call('icosa_edges_', PACKAGE = 'icosa', newGrid$v, e, icosa@center, 0))/pi*180)
			
		names(.Object@edgeLength) <- c("km", "deg")
		
		.Object@orientation<-c(0,0,0)
		
		#2d grid!
		if(sp==T){
				.Object@sp<-SpPolygons(.Object)
		}else{
			dummy<-NA
			.Object@sp<-dummy
		}
		
		
			
		return(.Object)
	
	}
)

	
#' Creation of a hexa-pentagonal tesselated icosahedral grid
#' 
#' \code{trigri} creates either a hexa-pentagonal grid based on the
#'    tesselation of an icosahedron.
#'
#' The grid structure functions as a frame for data graining, plotting and
#'	calculations. Data can be stored in layers that are linked to the grid object. In the current version only the 
#'	\code{facelayer} class is implemented which allows the user to render data to the cells
#'	of the grid which are called faces. 
#'	The grid 'user interface' is made up of three primary tables: the \code{@vertices} table for the coordinates of the vertice,
#'	the \code{faces} and the \code{edges} table that contain which vertices form which faces and edges respectively.
#'	In these tables the faces and vertices are sorted to form spirals that go down from the north pole in a counter-clockwise
#'	direction. In case grid subsetting is performed these tables get truncated.
#'	
#'	At finer resolutions, the large number of spatial elements render all calculations very resource demanding and slow, 
#'	therefore the hierarchical structure created during the tesselation procedure is retained for efficient implementations.
#'	These data are stored in a list in the slot \code{@skeleton} and are 0-indexed integer tables for Rccp-based functions. \code{$v} 
#'	stores vertex, \code{$f} the edge, and \code{$e} contains the edge data for plotting and calculations. In these tables
#'	the original hierarchy based orderings of the units are retained, during subsetting, additional vectors are used to indicate
#'	deactivation of these units. Any sort of meddling with the @skeleton object will lead to unexpected behavior.
#'	
#' @slot vertices Matrix of the vertex coordinates.
#'
#' @slot faces Matrix of the verticies forming the faces
#'
#' @slot edges Matrix of the vertices forming the edges.
#'
#'	@slot tesselation contains the tesselation vector.
#'
#'	@slot orientation contains the grid orientation in xyz 3d space, values in radian.
#'
#'	@slot center is the xyz coordinates of the grids origin/center.
#'
#'	@slot div vector contains the number of faces that a single face of the previous tesselation level is decomposed to.
#'
#'	@slot faceCenters contains the xyz coordinates of the centers of the faces on the surface of the sphere.	
#'
#'
#' @param tesselation An integer vector with the tesselation values. Each number
#'    describes the number of new edges replacing one original edge. Multiple series of tesselations
#' 	  are possible this way. The total tesselation is the product of the tesselation vector. 
#'	  Higher values result in more uniform cell sizes, but the larger number of tesselation series,
#'	  increases the speed of lookup functions
#'
#' @rdname hexagrid-class
#'  @name hexagrid
#'
#' @return A hexagonal grid object, with class \code{hexagrid}.
#' @examples
#' 		g <- hexagrid(c(8))
#' 		g1 <- hexagrid(c(2,3,4,5))
#' @exportClass hexagrid
hexagrid<-setClass(
	"hexagrid",
	contain="trigrid",
)

#' Constructor for the hexagrid class
#' @name hexagrid
#' @rdname hexagrid-class 
#' @exportMethod hexagrid
setMethod(
	"initialize",
	signature="hexagrid",
	definition=function(.Object, tesselation=1, sp=F, radius=authRadius){
			
		tGrid<-trigrid(tesselation, radius=radius)
		# v part of the skeleton and the active vertices
			# new $v: first part original vertices of the trigrid (faceCenters)
			# of the hexagrid
			# second par: original face centers of the trigrid (in the order of n and f)
			# vertices of the new hexagrid
			v<-rbind(tGrid@skeleton$v,tGrid@faceCenters[tGrid@skeleton$aF[as.logical(tGrid@skeleton$aF)],])
			rownames(v)<-NULL
			aV<-rep(FALSE, nrow(v))
			
			aV[(nrow(tGrid@skeleton$v)+1):length(aV)]<- tGrid@skeleton$aF[as.logical(tGrid@skeleton$aF)]
			
		# the number of original vertices
			nOrigV<-nrow(tGrid@skeleton$v)
			
			#vertices member (ordered in the trigrid)
			vertices<-tGrid@faceCenters
			rownames(vertices)<-paste("P", 1:nrow(vertices), sep="")
			
			#uiV - the R indexes of the vertices in $v
			uiV<-rep(0, nrow(vertices))
			uiV[aV[as.logical(aV)]]<-1:length(uiV)+nOrigV
			names(uiV)<-paste("P", 1:nrow(vertices), sep="")
			
		#the faces
			#triangular faces in the last tesselation
			fTemp<-tGrid@skeleton$f[(tGrid@skeleton$offsetF+1):nrow(tGrid@skeleton$f),1:3]
			
			#table of the subfaces:
			#first column: original vertices of trigrid, the internal order of hexagonal faces
			sF<-.Call('icosa_CreateHexaSubfaces_', PACKAGE = 'icosa', tGrid@skeleton$n, fTemp, nOrigV)
			
			#total faces table required for lookups
			f<-rbind(tGrid@skeleton$f, sF)
			
			# links the subfaces to their UI orders (0-no subface, 1: F1 in the ui)
			aSF<-rep(0, nrow(f))
			aSF[(nrow(tGrid@skeleton$f)+1):nrow(f)]<-tGrid@skeleton$aV[sF[,1]+1]
			
		#edges 
			#internal representation of edges - plotting
			e<-unique(sF[,2:3])
			
			#outer
			# the vertices with outer indices
			edges<-matrix(paste("P", aV[as.numeric(e)+1], sep=""), ncol=2)
			rownames(edges)<-paste("E", 1:nrow(edges), sep="")
			
			#activation - for subsetting
			aE<-rep(T, nrow(e))
			
		#faces matrix
			#the first column implies the face the subfaces belong to
			fOrdered<-unique(sF[order(sF[,1]),1:3])
			
			#which subfaces (R indices of rows in $f table) belong to which face
			#ordered like the internal representation of trigrids vertices!
			facesInternal<-.Call('icosa_HexaFaces_', PACKAGE = 'icosa', fOrdered)
			facesInternal[1:12,6]<-NA
			vF<-facesInternal
			
			#replace the vertex indices to the outer indices (names)
			facesExpandOut<-aV[as.numeric(facesInternal)+1]
			facesExpandOut[!is.na(facesExpandOut)]<-paste("P", facesExpandOut[!is.na(facesExpandOut)], sep="")
			
			#create a matrix
			facesExpandOut<-matrix(facesExpandOut, ncol=6)
			
			#reorder the faces from north to south
			faces<-facesExpandOut
			faces[tGrid@skeleton$aV,]<-facesExpandOut
			rownames(faces)<-paste("F", 1:nrow(faces), sep="")
			
			#uiF - will be used for subsetting
			indices<-tGrid@skeleton$aV[sF[,1]+1]
			
			uiF<-.Call('icosa_RetrieveIndexMat_', PACKAGE = 'icosa', indices)
			uiF[uiF==0]<-NA
			
			#add the offset (R indices)
			uiF<-uiF+nrow(tGrid@skeleton$f)
			rownames(uiF)<-paste("F", 1:nrow(uiF), sep="")
			
			# when doing subsetting:
			# 1. select the faces by names
			# 2. flatten with as.numeric()
			# 3. subset $f for rows
			# 4. unique the output -> than you can use the indices for $v
			
		#face centers
			faceCenters<-tGrid@vertices
			rownames(faceCenters) <- paste("F", 1:nrow(faceCenters), sep="")
			
			
			# the centers of the faces for plotting ($plotV)
			#ordered as tGrird@skeleton$v
			transFace<-t(faces)
			flatF<-as.character(transFace)
			nas<-is.na(flatF)
			flatF[nas]<-"P1"
			
			vertsF<-vertices[flatF,]
			vertsF[nas,]<-NA
			rownames(vertsF)<-NULL
			indF<-rep(1:nrow(faces),each=6)
			x<-tapply(vertsF[,1], indF, mean, na.rm=T)
			y<-tapply(vertsF[,2], indF, mean, na.rm=T)
			z<-tapply(vertsF[,3], indF, mean, na.rm=T)
			
			#still the outer order
			fcPlot<-cbind(x,y,z)
			
			#the inner order (which is necessary for plotting)
			plotV<-v
			plotV[tGrid@skeleton$uiV,]<-fcPlot[,]
			
			
			#the inner order
			
			# total skeleton
			aF<-tGrid@skeleton$aV
			
			skeleton<-list(f=f, vF=vF, aF=aF,aSF=aSF, uiF=uiF, v=v, aV=aV, uiV=uiV,plotV=plotV, e=e, aE=aE)
		
	
			.Object@tesselation <-tesselation
			.Object@div <-tGrid@div
		#user interface
			.Object@faces <- faces
			.Object@vertices <- vertices
			.Object@edges <- edges
			.Object@skeleton <- skeleton
			.Object@faceCenters <- faceCenters
			
			#edge Length calcualtion
			.Object@edgeLength <- c(
				mean(.Call('icosa_edges_', PACKAGE = 'icosa', skeleton$v, skeleton$e, tGrid@center, 1)),
				mean(.Call('icosa_edges_', PACKAGE = 'icosa', skeleton$v, skeleton$e, tGrid@center, 0))/pi*180)
				names(.Object@edgeLength) <- c("km", "deg")
			
			.Object@length<- c(
				"vertices"=nrow(.Object@vertices),
				"edges"=nrow(.Object@edges),
				"faces"=nrow(.Object@faces))
				
		
			#temporary solutions
			.Object@r <- tGrid@r
			.Object@center <- tGrid@center
			.Object@proj4string<- tGrid@proj4string
			.Object@orientation<-c(0,0,0)
			
		
		if(sp==T){
				.Object@sp<-SpPolygons(.Object)
		}else{
			dummy<-NA
			.Object@sp<-dummy
		}
		
		
			
		return(.Object)
		
	}
)
	
		




#' Subsetting an icosahedral grid
#' 
#' This is a generic function used to access data from either a triangular or hexagonal grid, using the facenames, integers or logical vectors. 
#' 
#' The function returns vertices, edges and faces of the grid pertaining to the specified faces that can be used for additional operations (e.g. plotting). 
#' The subscript vector can be either a logical, character or numeric one. The character vector should contain face names, the logical subscript should have th
#' the same length as the number of faces and will pertain to the facenames. The numericvector can either refer to indices to the rownames of faces in the faces slot, or
#' to surfaces bounded by longitude/latitude data. In the latter case, the the vector should contain an element with a names of at least one of the "lomax", "lamax", 
#' "lomin" or "lamin" strings. In case a subset from "the back of the Earth" a larger longitude to a smaller longitude value is needed (e.g. between 150° to -150°), 
#' use c(lomax=-150, lomin=150).
#' 
#' 
#' @param x Either a \code{trigrid} or a \code{hexagrid} object that will be subsetted.
#' 
#' @param subscript A vector, specifying the names of the face that are used for subsetting.
#' 
#' @examples
#'     #create a triangular grid
#'         g <- trigrid(c(2,2))
#'     #make a subset pertaining to the faces
#'         subG1 <- subset(g, facenames= c("F1", "F33"))
#'     
#'	   #additional way of subsetting
#'			subG2 <- g[1:15] # selects faces F1 through F15
#'     logicalSub<-sample(c(T,F), nrow(g@faces), replace=T)
#'			subG3 <- g[subG2]
#'     #plot the subset in 3d space
#'         plot3d(subg3)
#'
#' @rdname subset-methods
#' @aliases subset, trigrid-method
#' @return Subset of the input grid. The class of the original object is retained, the \code{@skeleton} slot contains all previous information.
#' @exportMethod subset
setMethod(
	"subset",
	signature="trigrid",
	definition=function(x, subscript){
	
	#	subscript<-c("F295", "F300")
	#	x<-grid
		
		#checking
		if(is.numeric(subscript)){
			#add checking for lat/long subsetting
			# lat-long mode of subsetting
			potConds<-c("lamin", "lamax", "lomin", "lomax")
			if(sum(names(subscript)%in%potConds)>0){
				#if it contains an unitelligible names
				if(sum(!names(subscript)%in%potConds)>0) 
					warning("Some subscript condition names were not recognized.")
				
				
				#in case you want something at the dateline
				normal <- T
				if(sum(c("lomax", "lomin")%in%names(subscript))==2){
					if(subscript["lomin"]>subscript["lomax"]){
						normal<- F
					}
				}
				
				#get the facecenters
				pol <- CarToPol(x@faceCenters, norad=T, origin=x@center)
				
				boolSelect<-rep(T, nrow(pol))
				
				#longitude
				if(normal){
					#minimum longitude condition
					if("lomin"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]>=subscript["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]<=subscript["lomax"]
					}
				}else{
					#minimum longitude condition
					if("lomin"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]>=subscript["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subscript)){
						boolSelect <- boolSelect | pol[,1]<=subscript["lomax"]
					}
				
				}
				
				#minimum latitude condition
				if("lamin"%in%names(subscript)){
					boolSelect <- boolSelect & pol[,2]>=subscript["lamin"]
				}
				
				#minimum latitude condition
				if("lamax"%in%names(subscript)){
					boolSelect <- boolSelect & pol[,2]<=subscript["lamax"]
				}
				
				subscript<-rownames(x@faceCenters)[boolSelect]
				# control will pass over to the subsetting by facenames

			}else{
			
			# index subsetting
				subscript<-paste("F", subscript, sep="")
			}
		}		
		
		if(is.logical(subscript)){
			if(length(subscript)==nrow(x@faces)){
				subscript<-rownames(x@faces)[subscript]
			}else{
				stop("Logical subscript has wrong length.")
			}
		}
		
		#check whether there are NAs in the subscript variables
		if(sum(is.na(subscript))){
			warning("The specified face names contain NA values.")
			#omit
			subscript<-subscript[!is.na(subscript)]
		}
		
		if(sum(!subscript%in%rownames(x@faces))>0) stop("Invalid face names entered.")
		
	
		#triGrid subset
		#1. subset of faces
			subsetFaces<-x@faces[subscript, ,drop=FALSE]
			
			# skeleton - faces - use skeleton$uiF to deactivate faces in skeleton$aF
			#false vector
			tempFacesLog<-rep(F, length(x@skeleton$aF))
			#what should not be removed
			tempFacesLog[x@skeleton$offsetF+x@skeleton$uiF[which(names(x@skeleton$uiF)%in%subscript)]] <- TRUE
			#remove everthing but that
			x@skeleton$aF[!tempFacesLog]<- FALSE
		
		#2. points
			pointnames<-unique(as.character(subsetFaces))
			subsetVertices<-x@vertices[pointnames,, drop=F]
			
			# skeleton - use skeleton$uiV to deactivate faces in skeleton$aV
			tempVerticesLog<-rep(F,length(x@skeleton$aV))
			tempVerticesLog[x@skeleton$uiV[which(names(x@skeleton$uiV)%in%pointnames)]] <- TRUE
			
			x@skeleton$aV[!tempVerticesLog] <- FALSE
		
		#3. subset of edges
			#the original logical of the edges
			edgeTemp<-x@skeleton$aE
			
			#logical for the points - kept or not?
			logE<-matrix(as.logical(x@skeleton$aV)[as.numeric(x@skeleton$e+1)], ncol=2)
			
			#where both points are needed in the subset, keep both!
			aE<-apply(logE,1, sum)==2
			x@skeleton$aE<-aE
			
			#use that but only where it was subsetted previous - for UI
			subsetEdges<-x@edges[aE[edgeTemp],, drop=F]
			
			
		
		
#			subsetEdges<-x@edges[x@edges[,1]%in%pointnames & x@edges[,2]%in%pointnames,]
#		
#			#simple function that could be iterated to get the edges in a face
#			edgesOfFace<-function(oneFace,subsetEdges)
#			{
#	#			oneFace<-subsetFaces[1,]
#				oneEdges<-rownames(subsetEdges[subsetEdges[,1]%in%oneFace & subsetEdges[,2]%in%oneFace,])
#			}
#			
#			#the names of the edges that outline the faces
#			edgeNames<-unique(as.character(apply(subsetFaces,1,edgesOfFace, subsetEdges)))
#		
#			subsetEdges<-subsetEdges[edgeNames,, drop=F]
#			# skeleton
#			x@skeleton$aE[x@skeleton$aE] <- rownames(x@edges)%in%edgeNames
			
		
		#4. subset of faceCenters
			subsetFaceCenters<-x@faceCenters[subscript,, drop=F]
			
		
		#6. copy over the original object
		#	y<-x
			
			#and change it accordingly
			x@vertices=subsetVertices
			x@faces=subsetFaces
			x@edges=subsetEdges
			x@faceCenters=subsetFaceCenters
			
			x@length<- c(
			"vertices"=nrow(x@vertices),
			"edges"=nrow(x@edges),
			"faces"=nrow(x@faces))
		
		
		return(x)
		
	}
)

#' @rdname subset-methods
#' @aliases subset, hexagrid-method
#' @exportMethod subset
setMethod(
	"subset",
	signature="hexagrid",
	definition=function(x, subscript){
	
		#checking
		if(is.numeric(subscript)){
			#add checking for lat/long subsetting
			# lat-long mode of subsetting
			potConds<-c("lamin", "lamax", "lomin", "lomax")
			if(sum(names(subscript)%in%potConds)>0){
				#if it contains an unitelligible names
				if(sum(!names(subscript)%in%potConds)>0) 
					warning("Some subscript condition names were not recognized.")
				
				
				#in case you want something at the dateline
				normal <- T
				if(sum(c("lomax", "lomin")%in%names(subscript))==2){
					if(subscript["lomin"]>subscript["lomax"]){
						normal<- F
					}
				}
				
				#get the facecenters
				pol <- CarToPol(x@faceCenters, norad=T, origin=x@center)
				
				boolSelect<-rep(T, nrow(pol))
				
				#longitude
				if(normal){
					#minimum longitude condition
					if("lomin"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]>=subscript["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]<=subscript["lomax"]
					}
				}else{
					#minimum longitude condition
					if("lomin"%in%names(subscript)){
						boolSelect <- boolSelect & pol[,1]>=subscript["lomin"]
					}
					
					#maximum longitude condition
					if("lomax"%in%names(subscript)){
						boolSelect <- boolSelect | pol[,1]<=subscript["lomax"]
					}
				
				}
				
				#minimum latitude condition
				if("lamin"%in%names(subscript)){
					boolSelect <- boolSelect & pol[,2]>=subscript["lamin"]
				}
				
				#minimum latitude condition
				if("lamax"%in%names(subscript)){
					boolSelect <- boolSelect & pol[,2]<=subscript["lamax"]
				}
				
				subscript<-rownames(x@faceCenters)[boolSelect]
				# control will pass over to the subsetting by facenames

			}else{
			
			# index subsetting
				subscript<-paste("F", subscript, sep="")
			}
		}		
		
		if(is.logical(subscript)){
			if(length(subscript)==nrow(x@faces)){
				subscript<-rownames(x@faces)[subscript]
			}else{
				stop("Logical subscript has wrong length.")
			}
		}
		
	#	subscript<-c("F295", "F300")
	#	x<-grid
	
		#check whether therer are NAs in the subscript variables
		if(sum(is.na(subscript))){
			warning("The specified face names contain NA values")
			#omit
			subscript<-subscript[!is.na(subscript)]
		}
		
		
		if(sum(!subscript%in%rownames(x@faces))>0) stop("Invalid face names entered.")
		
		# order the subscript vector to avoid any potential errors
			subscript<-sort(subscript)
		
		
		# hexaGrid subset
		#1. subset of faces
			#ui representation
			subsetFaces<-x@faces[subscript, ,drop=FALSE]
			
			# indexing of $f
			subFaceIndex<-as.numeric(x@skeleton$uiF[subscript,])
			aSF<-x@skeleton$aSF
			aSF[!1:length(x@skeleton$aSF)%in%subFaceIndex]<-0
		
			aF<-x@skeleton$aF
			aF[!paste("F",aF,sep="")%in%subscript]<-0
			
		#2. points 
		#2a.(vertices)
			pointnames<-unique(as.character(subsetFaces))
			subsetVertices<-x@vertices[rownames(x@vertices)%in%pointnames,]
		
			#indexing in $v
			aV<-x@skeleton$aV
			aV[!1:length(aV)%in%x@skeleton$uiV[rownames(subsetVertices)]]<-0
		
		
		#3b. subset of edges
			edgeTemp<-x@skeleton$aE
			
			logE<-matrix(as.logical(aV)[as.numeric(x@skeleton$e+1)], ncol=2)
			aE<-apply(logE,1, sum)==2
			
			subsetEdges<-x@edges[aE[edgeTemp],]
		
		#4. subset of faceCenters
			subsetFaceCenters<-x@faceCenters[subscript,, drop=F]
			
		#5. copy over the original object
			y<-x
			
			#and change it accordingly
			y@vertices=subsetVertices
			y@faces=subsetFaces
			y@edges=subsetEdges
			y@faceCenters=subsetFaceCenters
			
			y@skeleton$aV<-aV
			y@skeleton$aSF<-aSF
			y@skeleton$aE<-aE
			y@skeleton$aF<-aF
			
			y@length<- c(
			"vertices"=nrow(y@vertices),
			"edges"=nrow(y@edges),
			"faces"=nrow(y@faces))
		
			return(y)
		
	}
)

# shorthand
setMethod(
	"[",
	signature="trigrid",
	definition=function(x,i,j,..., drop=T){
		subset(x, i)
	
	}
)



#' 3d plotting of an icosahedral grid or its subset
#' 
#' This is a generic function used to plot either a \code{trigrid} or a \code{hexagrid} object or their \code{facelayer} in 3d space. 
#' 
#' The function is built on the openGL renderer of the R package \code{rgl}.
#'  
#' @param x The \code{trigrid}, \code{hexagrid} or \code{facelayer} object to be plotted.
#' 
#' @param type A character value specifying the part of the grid to be plotted by the call of the function. 
#' \code{"v"} plots the grid vertex points. 
#' \code{"e"} draws the grid edges.
#' \code{"f"} draws the grid faces.
#' \code{"c"} draws the face centers of the grid.
#' 
#' @param sphere Defaults to NULL, adding a central white sphere to the plot. Assigning a numeric value will draw a new sphere with the given radius,
#'		\code{FALSE} does not plot the sphere. 
#' 
#' @param ... Further graphical parameters passed to (see \code{\link[rgl]{plot3d}}).
#' 
#' @return The function does not return any value.
#'
#' @rdname plot3d-method
#'
#' @examples
#' # create a hexagonal grid
#'     g <- hexagrid(c(2,2))
#' # plot the grid in 3d space
#'     plot3d(g, col="blue")
#' # make a subset to select faces
#'    subG <- subset(g, c("F5", "F2"))
#' # plot the subset defined above
#'     plot3d(subset, type="f", col=c("orange"), add=T, lwd=1)
#' @rdname plot3d-methods
#' @aliases plot3d, trigrid-method
#' @exportMethod plot3d
setMethod(
	"plot3d",
	signature="trigrid",
	definition=function(x, type=c("l"),sphere=NULL,  add=F, guides=T, ...){
	
		require(rgl)
		
		#create new plot?
		if(add==F)
		{
			#checking plotting
			plot3d(x@vertices, type="n", box=F, axes=F, xlab="", ylab="", zlab="")
			
			#default sphere plotting
			if(is.null(sphere)){
				#get the radius
				fc<-apply(x@vertices[x@faces[1,],],2,mean)-x@center
				rad<-sqrt(fc[1]^2+fc[2]^2+fc[3]^2)-15
				rgl.sphere(origin[1],origin[2], origin[3], radius = rad, color ="white", ng=200, box=F, axes=F)
			}else{
				if(sphere){
					rgl.sphere(origin[1],origin[2], origin[3], radius = sphere, color ="white", ng=200, box=F, axes=F)
				}
			}
		}
		
		
		if(type=="p")
		{
			#single point
			if(length(x@vertices)==3)
			{
				points3d(x=x@vertices[1],y=x@vertices[2],z=x@vertices[3],...)
			}else{
				points3d(x@vertices, ...)
			}
		}
			
		if(type=="l")
		{
			lines3d(x, ...)
		}
		
		if(type=="f")
		{
			faces3d(x,...)
		}
		
		if(type=="n"){
		
		}
		# guides
		if(guides){
			guides3d(col="green", origin=x@center, radius=x@r, lwd=2)
		}
		
		
	}
)
#' 3d plotting of an icosahedral grid or its subset
#' @rdname plot3d-method
#' @aliases plot3d, hexagrid-method
#' @exportMethod plot3d
setMethod(
	"plot3d",
	signature="hexagrid",
	definition=function(x, type=c("l"),sphere=NULL, color="gray70", add=F, guides=T, ...){
	
		require(rgl)
		
		#create new plot?
		if(add==F)
		{
			#checking plotting
			plot3d(x@vertices, type="n", box=F, axes=F, xlab="", ylab="", zlab="")
			
			#default sphere plotting
			if(is.null(sphere)){
				fVect<-x@faces[2,!is.na(x@faces[2,])]
				#get the radius
				fc<-apply(x@vertices[fVect,],2,mean)-x@center
				rad<-sqrt(fc[1]^2+fc[2]^2+fc[3]^2)-10
				rgl.sphere(origin[1],origin[2], origin[3], radius = rad, color ="white", ng=200, box=F, axes=F)
			}else{
				if(sphere){
					rgl.sphere(origin[1],origin[2], origin[3], radius = sphere, color ="white", ng=200, box=F, axes=F)
				}
			}
		}
		
		
		if(type=="p")
		{
			#single point
			if(length(x@vertices)==3)
			{
				points3d(x=x@vertices[1],y=x@vertices[2],z=x@vertices[3], col=color,...)
			}else{
				points3d(x@vertices, col=color, ...)
			}
		}
			
		if(type=="l")
		{
			lines3d(x, ...)
		}
		
		if(type=="f")
		{
			faces3d(x,...)
		}
		
		if(type=="c")
		{
			#single point
			if(length(x@faceCenters)==3)
			{
				points3d(x=x@faceCenters[1],y=x@faceCenters[2],z=x@faceCenters[3], col=color, ...)
			}else{
				points3d(x@faceCenters, col=color, ...)
			}
		}
		
		if(type=="t")
		{
			text3d(x@faceCenters, texts=rownames(x@faceCenters),col=color, ...)
		}
		
		if(type=="n"){
		
		}
		if(guides){
			guides3d(col="green", origin=x@center, radius=x@r, lwd=2)
		}
		
		
	}
)



#' Methods of 3d line plotting.
#' 
#' This is a generic function used to plot the edge lines of either a \code{trigrid} or a \code{hexagrid} object in 3d space. The method is also implemented for 
#' the object classes of defined by the package 'sp'.
#' 
#' The function is built on the openGL renderer of the R package \code{rgl} and directly 
#'  
#' @param x The \code{trigrid}, \code{hexagrid} or \code{facelayer} object to be plotted.
#' 
#' @param ... Further graphical parameters passed to (see \code{\link[rgl]{plot3d}}).
#' 
#' @return The function does not return any value.
#'
#' @examples
#' # create a hexagonal grid
#'     g <- hexagrid(c(2,2))
#' # plot the grid in 3d space
#'     plot3d(g, col="blue")
#' # make a subset to select faces
#'    subG <- subset(g, c("F5", "F2"))
#' # plot the subset defined above
#'     plot3d(subset, type="f", col=c("orange"), add=T, lwd=1)
#' @rdname lines3d-method
#' @aliases lines3d, trigrid-method
#' @exportMethod lines3d
setMethod(
	"lines3d",
	signature="trigrid",
	definition=function(x, ...){
		v<-x@skeleton$v
		e<-x@skeleton$e[x@skeleton$aE,]
		
		#create edgeMat with a simple Rccp function
		edgeMat<-.Call('icosa_edgeMatTri_', PACKAGE = 'icosa', v=v, e=e)
		
		segments3d(x=edgeMat[,1],y=edgeMat[,2],z=edgeMat[,3], ...)
	}
)


#' Methods of 3d face plotting.
#' 
#' This is a generic function used to plot the faces of either a \code{trigrid} or a \code{hexagrid} object in 3d space. 
#' 
#' The function is built on the openGL renderer of the R package \code{rgl} and directly 
#'  
#' @name faces3d
#' @param x The \code{trigrid}, \code{hexagrid} or \code{facelayer} object to be plotted.
#' 
#' @param ... Further graphical parameters passed to (see \code{\link[rgl]{plot3d}}).
#' 
#' @return The function does not return any value.
#'
#' @examples
#' # create a hexagonal grid
#'     g <- hexagrid(c(2,2))
#' # plot the grid in 3d space
#'     plot3d(g, col="blue")
#' # make a subset to select faces
#'    subG <- subset(g, c("F5", "F2"))
#' # plot the subset defined above
#'     plot3d(subset, type="f", col=c("orange"), add=T, lwd=1)
#' @exportMethod faces3d
#' @rdname faces3d-methods
	setGeneric(
		name="faces3d",
		package="icosa",
		def=function(x,...){
			standardGeneric("faces3d")
			
		}
	)


#' @rdname faces3d-methods
#' @aliases faces3d, trigrid-method	
setMethod(
	"faces3d",
	signature="trigrid",
	definition=function(x, ...){
		
		v<-x@skeleton$v
		f<-x@skeleton$f[as.logical(x@skeleton$aF),1:3]
		
		#create edgeMat with a simple Rccp function
		triMat<- .Call('icosa_triMatTri_', PACKAGE = 'icosa', v, f)
		
		triangles3d(x=triMat[,1],y=triMat[,2],z=triMat[,3],...)
			
	}
)


#' @rdname faces3d-methods
#' @aliases faces3d, hexagrid-method	
setMethod(
	"faces3d",
	signature="hexagrid",
	definition=function(x,...){
		v<-x@skeleton$plotV
		f<-x@skeleton$f[as.logical(x@skeleton$aSF),1:3]
		
	#	f2<-f[order(f[,1]),]
	#	
	#	f2<-unique(f2)
		
		#create edgeMat with a simple Rccp function
		triMat<- .Call('icosa_triMatTri_', PACKAGE = 'icosa', v, f)
		
		triangles3d(x=triMat[,1],y=triMat[,2],z=triMat[,3],...)
	
	
	}
)

#' Guides for 3d spherical plotting.
#' 
#' This function plot 3d guidelines for navigation on the surface of the sphere.
#' 	this includes the drawing of the rotational axis and a polar coordinate system.
#' 
#' The function is built on the openGL renderer of the R package \code{rgl} and directly 
#'  
#' @param axis numeric argument draws the 0 axis, with radius 'axis' times the authalic radius ca. 6371km.
#' 
#' @param polgrid numeric argument with the length of 2, where the first argument specifies
#' the length of the longitudenal and the second the breadth of the latitudinal divisions.
#'
#' @param res numeric argument for graphical resolution of the curves:
#' the distance in degrees between the points of the rendered guides. 
#' 
#' @return The function does not return any value.
#'
#' @examples
#' # create a hexagonal grid
#'     g <- hexagrid(c(2,2))
#' # plot the grid in 3d space
#'     plot3d(g, col="blue")
#' # make a subset to select faces
#'    subG <- subset(g, c("F5", "F2"))
#' # plot the subset defined above
#'     plot3d(subset, type="f", col=c("orange"), add=T, lwd=1)
#' @export
guides3d<-function(axis=1.5, polgrid=c(30,30), compass=NULL, textPG=NULL, res=1,  origin=c(0,0,0), radius=authRadius, drad=1.1, ...){
	
	if(!is.null(axis)){
		segments3d(x=c(0,0), y=c(0,0), z=c(-axis*radius,axis*radius),...)
		segments3d(x=c(200,0), y=c(0,0), z= c(axis*radius-500,axis*radius),...)
		segments3d(x=c(-200,0), y=c(0,0), z= c(axis*radius-500,axis*radius),...)
	}
	if(!is.null(polgrid[1])){

		if(360%%polgrid[1]!=0) 
			stop(paste("360 is not divisble by ", polgrid[1],sep=""))
		if(180%%polgrid[2]!=0) 
			stop(paste("180 is not divisble by ", polgrid[2],sep=""))
		
		#meridians
		#division
		usedLongs<-seq(-180,180,polgrid[1])
		a<-usedLongs
		#resolution
		b<-c(seq(-90,90,res), NA)
		
		lngs<-rep(a,each=length(b))
		lngs[1:length(a)*length(b)]<-NA
		
		lats<-rep(b, length(a))
		merid<-cbind(lngs, lats)
		merid3d<-PolToCar(merid,origin=origin, radius=radius)
		
		#lat circles
		#division
		usedLats<-seq(-90,90,polgrid[2])
		a<-usedLats
		#resolution
		b<-c(seq(-180,180,res),NA)
		
		
		lats<-rep(a,each=length(b))
		lats[1:length(a)*length(b)]<-NA
		
		lngs<-rep(b, length(a))
		latC<-cbind(lngs, lats)
		
		latC3d<-PolToCar(latC,origin=origin, radius=radius)
		
		lines3d(merid3d,...)
		lines3d(latC3d,...)
		
		if(!is.null(textPG)){
			# the latitudes
			latTab<-cbind(rep(0,length(usedLats)), usedLats)
			coordLat<-PolToCar(latTab, origin=origin, radius=radius)*drad
			text3d(coordLat, text=usedLats, ...)
		
		# the longitudes
			# you need only 180, no -180
			usedLongs<- usedLongs[-length(usedLongs)]
			longTab<-cbind(usedLongs,rep(0,length(usedLongs)))
			coordLong<-PolToCar(longTab, origin=origin, radius=radius)*drad
			text3d(coordLong, text=usedLongs, ...)
		
		}
		
	}
	
	if(!is.null(textPG)){
		
	}
	
	if(!is.null(compass)){
	
	
	}

}


#' Display the names of the grid elements in 3d plots.
#' 
#' This function will display the names of vertices, faces and edges on 3d plots.
#' 
#' @name gridlabs3d
#'  
#' @param gridObj A \code{trigrid} or \code{hexagrid} object to be plotted.
#' 
#' @param type A character vector containing either "f", "e" or "v", rendering the names
#' of either the faces, edges or vertives respectively.
#'
#' @param ... further arguments passed to \code{text3d} of the rgl package.
#' 
#' @return The function does not return any value.
#'
#' @examples
#' # create a hexagonal grid
#'     g <- hexagrid(c(2,2))
#' # plot the grid in 3d space
#'     plot3d(g, col="blue")
#' # make a subset to select faces
#'    subG <- subset(g, c("F5", "F2"))
#' # plot the subset defined above
#'     plot3d(subset, type="f", col=c("orange"), add=T, lwd=1)
#' @exportMethod gridlabs3d
#' @rdname gridlabs3d-methods
setGeneric(
	name="gridlabs3d",
	package="icosagrid",
	def=function(gridObj,...){
		standardGeneric("gridlabs3d")
		
	}
)

#' @rdname gridlabs3d-methods
#' @aliases gridlabs3d, trigrid-method
setMethod(
	"gridlabs3d",
	signature="trigrid",
	definition=function(gridObj,type="f",...){
		
		# vertex names
		if("v"%in%type){
			text3d(texts=rownames(gridObj@vertices), gridObj@vertices*1.005,...)
		}
		
		
		if("f"%in%type){
			text3d(texts=rownames(gridObj@faceCenters), gridObj@faceCenters*1.005,...)
		}
		
		if("e"%in%type){
			#the coordinates
			coords<-apply(gridObj@edges,1,function(x){
				apply(gridObj@vertices[x,], 2, mean)
			})
			
			text3d(t(coords)*1.005, texts=rownames(gridObj@edges),...)
		}
	
	
	}
)
	
#' @rdname gridlabs3d-methods
#' @aliases gridlabs3d, hexagrid-method
setMethod(
	"gridlabs3d",
	signature="hexagrid",
	definition=function(gridObj,type="f",...){
		
		# vertex names
		if("v"%in%type){
			text3d(texts=rownames(gridObj@vertices), gridObj@vertices*1.005,...)
		}
		
		
		if("f"%in%type){
			text3d(texts=rownames(gridObj@faceCenters), gridObj@faceCenters*1.005,...)
		}
		
		if("e"%in%type){
			#the coordinates
			coords<-apply(gridObj@edges,1,function(x){
				apply(gridObj@vertices[x,], 2, mean)
			})
			
			text3d(t(coords)*1.005, texts=rownames(gridObj@edges),...)
		}
	
	
	}
)
