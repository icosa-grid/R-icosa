

#' Conversion of spherical coordinates to 3d Cartesian coordinates
#' 
#' The function uses basic trigonometric relationships to transform longitude/latitude coordinates on a sphere to xyz coordinates.
#' 
#' The authalic radius mean radius of Earth (6371.007 km) is used by this function as a default and origin is c(0,0,0). The precision of these conversions is not exact (see example c(0,90) below),
#' but should be considered acceptable when applied at a reasonable scale (e.g. for global analyses using data above 10e-6 meters of resolution).
#' 
#' @param longLatMat A 2-column numerical matrix with the longitude/latitude data.
#' 
#' @return An xyz 3-column numeric matrix.
#' 
#' @export PolToCar
#'
#' @examples 
#'     longLat <- rbind(
#'         c(0,0),
#'         #note the precision here!
#'         c(0, 90),
#'         c(-45,12)
#'     )
#'     
#'     xyz <- PolToCar(longLat)
PolToCar<-function(longLatMat, radius=authRadius, origin=c(0,0,0)){
#sometimes produces warnings!!!!!
	#ignore the NAs
	boolNA<-(is.na(longLatMat[,1]) | is.na(longLatMat[,2]))
	longLat<-longLatMat[!boolNA,, drop=F]
	
	if(length(radius)!=1 | !is.numeric(radius)) stop("Invalid \'radius\' value.")
	
	#essential! check whether the long is first and lat is second
	if(max(abs(longLat[,2]))>90) stop("Latitudinal data should be in the second column of the matrix.")
	
	x<-cos(longLat[,2]/180*pi)*cos(longLat[,1]/180*pi)
	y<-cos(longLat[,2]/180*pi)*sin(longLat[,1]/180*pi)
	z<-sin(longLat[,2]/180*pi)
	
	newMat<-matrix(NA, ncol=3, nrow=nrow(longLatMat))
	newMat[!boolNA,]<-cbind(x,y,z)
	colnames(newMat)<-c("x", "y", "z")

	endRes<-newMat*radius
	
	# do the translocation if necessary
	endRes[,1]<-endRes[,1]+origin[1]
	endRes[,2]<-endRes[,2]+origin[2]
	endRes[,3]<-endRes[,3]+origin[3]
	
	return(endRes)

}


#' Conversion of 3d Cartesian coordinates to spherical coordinates
#' 
#' The function uses basic trigonometric relationships to transform xyz coordinates to polar coordinates
#' 
#' The origin of the Cartesian space defaults to c(0,0,0).
#' 
#' @param matXYZ 3-column numeric matrix containing xyz coordinates in a Cartesian space
#' 
#' @return a 3-column numeric matrix returning longitude, latitude and radius data
#' 
#' @examples
#' # some random points
#' xyz <- rbind(
#'         c(6371, 0,0),
#'         c(0, 6371,0),
#'         c(1000,1000,1000)
#'     )
#' 
#' # conversions
#'     CarToPol(xyz)
#' @export CarToPol
CarToPol<-function(matXYZ, norad=F, origin=c(0,0,0)) {
	#ignore the NAs
	boolNA<-(is.na(matXYZ[,1]) | is.na(matXYZ[,2]) | is.na(matXYZ[,3]))
	matXYZ<-matXYZ[!boolNA,, drop=F]
	
	# center the coordinates to the center of c(0,0,0)
	matXYZ[,1]<-matXYZ[,1]-origin[1]
	matXYZ[,2]<-matXYZ[,2]-origin[2]
	matXYZ[,3]<-matXYZ[,3]-origin[3]
	
	
	#transform back to spherical coordinates
		xSign<-sign(matXYZ[,1])
	
		theta<-atan(matXYZ[,2]/matXYZ[,1])
		phi<-atan(sqrt(matXYZ[,1]^2+matXYZ[,2]^2)/matXYZ[,3])
	
	#transform spherical coordinates to long/lat
		theta<-theta/pi*180
		phi<-phi/pi*180
	
		#convert to lat-long
		long<-rep(NA, length(theta))
		lat<-rep(NA, length(phi))
		
		lat[phi>=0]<-90-phi[phi>=0]
		lat[phi<0]<--90-phi[phi<0]
		
		long[xSign<0 & theta<=0]<-180+theta[xSign<0 & theta<=0]
		long[xSign<0 & theta>0]<--180+theta[xSign<0 & theta>0]
		long[xSign>=0]<-theta[xSign>=0]
	
		rho<-sqrt(matXYZ[,1]^2+matXYZ[,2]^2+matXYZ[,3]^2)
		
		if(sum(is.nan(long))>0)
		{
			long[is.nan(long)]<-0
		
		}
		#the polar problem:
		lat[lat==90 & matXYZ[,3]<0]<- -90
		
		
	if(norad){
		matLongLat<-matrix(NA, ncol=2, nrow=length(boolNA))
		matLongLat[!boolNA,]<-cbind(long, lat)
		rownames(matLongLat)<-rownames(matXYZ)
		colnames(matLongLat)<-c("long", "lat")
		return(matLongLat)
		
	}else{	
		matLongLat<-matrix(NA, ncol=3, nrow=length(boolNA))
		matLongLat[!boolNA,]<-cbind(long, lat, rho)
		rownames(matLongLat)<-rownames(matXYZ)
		colnames(matLongLat)<-c("long", "lat", "rho")
		return(matLongLat)
		
	}
		
}


#simple function to split great circle arcs
#' Calculation of points along an arc
#' 
#' This function calculates points along an arc between two points and and a circle center.
#' 
#' The function always returns the smaller arc, with angle < pi.
#' 
#' @param p1 XYZ or longitude-latitude coordinates of the first point along the arc.
#' 
#' @param p2 XYZ or longitude-latitude coordinates of the last point along the arc.
#' 
#' @param origin The center of the circle in XYZ coordinates (default is 0,0,0).
#' 
#' @param breaks Single positive integer, the number of points inserted between p1 and p2.
#' 
#' @param onlyNew Logical value whether the result should get rid of p1 and p2 or not.
#' 
#' @param output The coordinate system of the output points. Can either be \code{"polar"} for
#' 	longitude-latitude or \code{"cartesian"} for XYZ data.
#'
#' @param radius The radius of the circle in case the input points have only polar coordinates.
#'	Unused when XYZ coordinates are entered.
#' 
#' @return Either an XYZ or a long-lat matrix.
#' 
#' @examples
#'	plot(NULL, NULL, xlim=c(-180, 180), ylim=c(-90,90))
#'	p1<-c(-45,-70)
#'	p2<-c(130,65)
#'	points(arc(p1, p2, breaks=70, output="polar"))
#'
#' @export arc
arc<-function(p1,p2,breaks=2,origin=c(0,0,0), onlyNew=FALSE, output="cartesian", radius=authRadius){
	if(!output%in%c("cartesian", "polar")) stop("Invalid \'output\' argument.")
	
	if(!is.logical(onlyNew)| length(onlyNew)>1) "Invalid \'onlyNew\' argument."

	if(!is.numeric(breaks) | length(breaks)!=1 | breaks%%1!=0) stop("Invalid \'breaks\' argument")
	
	if(!is.numeric(p1) | !is.numeric(p2) | !is.numeric(origin)) stop("Invalid coordinate input.")
	
	if(!sum(is.finite(p1))%in%c(2,3) | 
		!sum(is.finite(p2))%in%c(2,3) | 
		!sum(is.finite(origin))%in%c(2,3)) stop("Invalid coordinate input.")
	
	if(length(p1)==2){
		p1<-PolToCar(matrix(p1, ncol=2, nrow=1),radius=radius, origin=origin)
		p1<-p1[1,]
	}
	
	if(length(p2)==2){
		p2<-PolToCar(matrix(p2, ncol=2, nrow=1),radius=radius, origin=origin)
		p2<-p2[1,]
	}
		
	#invoke Rcpp function
	temp<-.Call('icosa_SplitArc_', PACKAGE = 'icosa', p1, p2, origin, breaks, onlyNew)
	
	colnames(temp)<-c("x", "y", "z")
	
	if(output=="polar"){
		temp<- CarToPol(temp, norad=T, origin=origin )
	}
	
	return(temp)
}

#' Calculation of distances along arcs
#' 
#' This function calculates the shortest arc distance between two points.
#' 
#' @param p1 XYZ or longitude-latitude coordinates of the first point along the arc.
#' 
#' @param p2 XYZ or longitude-latitude coordinates of the last point along the arc.
#' 
#' @param origin The center of the circle in XYZ coordinates (default is 0,0,0).
#' 
#' @param output The type of the output value. \code{"distance"} will give back the distance
#'	in the metric that was fed to the function in the coordinates or the radius.
#'	\code{"deg"} will output the the distance in degrees, \code{"rad"} will do
#'	so in radians.
#'
#' @param radius The radius of the circle in case the input points have only polar coordinates.
#'	Unused when XYZ coordinates are entered.
#'
#' @return A single numeric value.
#'
#' @examples 
#'	p1<- c(0,0)
#'	p2<- c(180,0)
#'	arcdist(p1,p2,"distance")
#' @export arcdist
arcdist <- function(p1, p2, output="distance", origin=c(0,0,0), radius=authRadius) {
    if(!is.numeric(p1) | !is.numeric(p2) | !is.numeric(origin)) stop("Invalid coordinate input.")
	
	if(!output%in%c("distance", "deg", "rad")) stop("Invalid \'output\' argument.")
	
	if(!sum(is.finite(p1))%in%c(2,3) | 
		!sum(is.finite(p2))%in%c(2,3) | 
		!sum(is.finite(origin))%in%c(2,3)) stop("Invalid coordinate input.")
	
	if(length(p1)==2){
		p1<-PolToCar(matrix(p1, ncol=2, nrow=1),radius=radius, origin=origin)
		p1<-p1[1,]
	}
	
	if(length(p2)==2){
		p2<-PolToCar(matrix(p2, ncol=2, nrow=1),radius=radius, origin=origin)
		p2<-p2[1,]
	}
		
	if(output=="distance") method<-T
	if(output%in%c("deg", "rad")) method<-F
	
	result<-.Call('icosa_ArcDist_', PACKAGE = 'icosa', p1, p2, origin, method)
	
	#acos() out of domain error
		if(is.nan(result) & output=="distance"){
			v<-p1-origin
			result <- pi*sqrt(v[1]^2+v[2]^2+v[3]^2)
		} 
		
		if(is.nan(result) & output%in%c("deg","rad")){
			v<-p1-origin
			result <- pi
		} 
	
	if(output=="deg"){
		result<-result*180/pi
	}

	return(result)
	
}

#' Calculation of distance matrices along arcs
#' 
#' This function calculates the shortest arc distance matrix between two set of points.
#' 
#' This function will create all possible shortest arc distances between points in the two sets,
#' 	but not between the points within the sets. The function is useful for great circle distance calculations.
#' 	For a symmetrical distance matrix leave the \code{points2} argument empty.
#' 
#' @param points1 XYZ or longitude-latitude coordinates (matrix) of the first set of points.
#' 
#' @param points2 XYZ or longitude-latitude coordinates (matrix) of the second set of points. 
#'	Leave this empty if you want all the arc distances between a set of points	
#' 
#' @param origin The center of the circle in XYZ coordinates (default is 0,0,0).
#' 
#' @param output The type of the output value. \code{"distance"} will give back the distance
#' 	in the metric that was fed to the function in the coordinates or the radius.
#' 	\code{"deg"} will output the the distance in degrees, \code{"rad"} will do
#' 	so in radians.
#' 
#' @param radius The radius of the circle in case the input points have only polar coordinates.
#' 	Unused when XYZ coordinates are entered.
#' 
#' @return A single numeric value.
#' 
#' @examples
#' 	g <- trigrid(c(4))
#' 	res <- arcdistmat(g@vertices)
#' 	
#' 	rand<-rpsphere(500)
#' 	res2 <- arcdistmat(g@vertices, rand)
#'
#'	@export
arcdistmat<-function(points1, points2=NULL, origin=c(0,0,0), output="distance", radius=authRadius){
	# output argument
	if(!output%in%c("distance", "deg", "rad")) stop("Invalid \'output\' argument.")
	if(output=="distance") method<-T
	if(output%in%c("deg", "rad")) method<-F
	
	present<-T
	if(is.null(points2)){
		points2<-points1
		present<-F
	}
	
	if(!is.numeric(points1) | !is.numeric(points2) | !is.numeric(origin)) stop("Invalid coordinate input.")
	
	
	if(!ncol(points1)%in%c(2,3) | 
		!ncol(points2)%in%c(2,3) | 
		!sum(is.finite(origin))%in%c(2,3)) stop("Invalid coordinate input.")
	
	if(sum(is.na(points1))>0 | sum(is.na(points2))>0) stop("The coordinates include NAs")
	if(ncol(points1)==2){
		points1<-PolToCar(matrix(points1, ncol=2, nrow=1),radius=radius, origin=origin)
		points1<-points1[1,]
	}
	
	
	
	if(ncol(points2)==2){
		points2<-PolToCar(matrix(points2, ncol=2, nrow=1),radius=radius, origin=origin)
		points2<-points2[1,]
	}
		
	if(present){
		distMat<- .Call('icosa_ArcDistMat_', PACKAGE = 'icosa', points1, points2, origin, method)
	}else{
		distMat<- .Call('icosa_SymmetricArcDistMat_', PACKAGE = 'icosa', points1, origin, method)
	}
	
	rownames(distMat)<-rownames(points1)
	colnames(distMat)<-rownames(points2)
	
	#acos() out of domain error
		if(sum(is.nan(distMat))>0 & output=="distance"){
			v<-points1[1,]-origin
			distMat[is.nan(distMat)] <- pi*sqrt(v[1]^2+v[2]^2+v[3]^2)
		} 
		
		if(sum(is.nan(distMat))>0 & output%in%c("deg","rad")){
			v<-points1[1,]-origin
			distMat[is.nan(distMat)] <- pi
		} 

		
	if(output=="deg"){
		distMat<-distMat*180/pi
	}
	return(distMat)
}



# this isnot to be exported!
SphericalTriangleCenter<- function(m=NULL, origin=c(0,0,0), output=c("cartesian")) {
	if(output%in%c("cartesian", "polar")) stop("Invalid output method.")
	
	if(!ncol(m)%in%c(2,3) | !is.numeric(m)) 
		stop("Invalid input, provide an xyz or a long-lat matrix.")
	
	if(ncol(m)==2){
		m<-PolToCar(m, origin=origin)
	}

    res<-.Call(
		'icosa_SphericalTriangleCenter_', 
		PACKAGE = 'icosa', 
		v0=m[,1], 
		v1=m[,2], 
		v2=m[,3], 
		origin
	)
	
	if(output=="cartesian"){
		colnames(res)<-c("x", "y", "z")
		return(res)
	}else{
		res<-CarToPol(res, origin=origin)
		colnames(res)<-c("long", "lat")
		return(res)
	}
}



#area of a spherical triangle-points can be entered both by a names vector,m or by coordinates
AreaSphericalTriangle<-function(points=NULL, pointCoord1=NULL,pointCoord2=NULL,pointCoord3=NULL,obj=grid, origin=c(0,0,0)){
	if(is.null(points)){
	#	point1<-obj$faces[1,1]
	#	point2<-obj$faces[1,2]
	#	point3<-obj$faces[1,3]
		
	#	pointCoord1<-obj$vertices[point1,]
	#	pointCoord2<-obj$vertices[point2,]
	#	pointCoord3<-obj$vertices[point3,]
	}else{
		pointCoord1<-obj$vertices[points[1],]
		pointCoord2<-obj$vertices[points[2],]
		pointCoord3<-obj$vertices[points[3],]
	}
	
	
	radius<-dist(rbind(pointCoord1,origin))
	
	ang12<-ArcDist(pointCoord1,pointCoord2,origin=origin)/radius
	ang13<-ArcDist(pointCoord1,pointCoord3,origin=origin)/radius
	ang23<-ArcDist(pointCoord2,pointCoord3,origin=origin)/radius
	
	dihedralAngle<-function(a,b,c)
	{
		acos((cos(a)-(cos(b)*cos(c)))/(sin(b)*sin(c)))
	}
	
	d12<-dihedralAngle(ang12,ang13,ang23)
	d13<-dihedralAngle(ang13,ang12,ang23)
	d23<-dihedralAngle(ang23,ang12,ang13)
	
	surface<-as.numeric(radius^2*((d12+d13+d23)-pi))
	
	return(surface)

}


#testing the tesselation
#	temp<-TesselateTriangle(faceName="F6",obj=icosa,lineBreak=13, method="spherical")
#	
#	plot3d(icosa$vertices)
#	points3d(temp$vertices, col="red")
#	text3d(rownames(temp$vertices),x=temp$vertices[,"x"],y=temp$vertices[,"y"],z=temp$vertices[,"z"], col="red")
	
#	#plot edges
#	for(i in 1:nrow(temp$edges))
#	{
#		lines3d(x=temp$vertices[temp$edges[i,],1], y=temp$vertices[temp$edges[i,],2],temp$vertices[temp$edges[i,],3])
#	}
#
#	#plot faces
#	for(i in 1:nrow(temp$faces))
#	{
#		triangles3d(temp$vertices[temp$faces[i,],1], temp$vertices[temp$faces[i,],2], temp$vertices[temp$faces[i,],3], col=paste("gray", 20+i*2, sep=""))
#	}



# this is a 3d plotting aid written by a guy#
# http://stackoverflow.com/users/557884/sezen
#create a highly round sphere
rgl.sphere <- function (x, y=NULL, z=NULL, ng=100, radius = 6350, color="white", add=F, ...) {
  lat <- matrix(seq(90, -90, len = ng)*pi/180, ng, ng, byrow = TRUE)
  long <- matrix(seq(-180, 180, len = ng)*pi/180, ng, ng)

  vertex  <- rgl:::rgl.vertex(x, y, z)
  nvertex <- rgl:::rgl.nvertex(vertex)
  radius  <- rbind(vertex, rgl:::rgl.attr(radius, nvertex))[4,]
  color  <- rbind(vertex, rgl:::rgl.attr(color, nvertex))[4,]

  for(i in 1:nvertex) {
    add2 <- if(!add) i>1 else T
    x <- vertex[1,i] + radius[i]*cos(lat)*cos(long)
    y <- vertex[2,i] + radius[i]*cos(lat)*sin(long)
    z <- vertex[3,i] + radius[i]*sin(lat)
    persp3d(x, y, z, specular="white", add=add2, color=color[i], ...)
  }
}



collapse<-function(vect){
	oldClass<-class(vect)
	factorized<-factor(vect)
	newFactor<-factor(.Call('icosa_Collapse_', PACKAGE = 'icosa', factorized))
	levels(newFactor)<-levels(factorized)
	newVect<-as.character(newFactor)
	class(newVect) <- oldClass
	return(newVect)
}

# function to calculate the normal great circle betwene two points
normalGC <- function(point1, point2, origin, breaks){
#	point1<-a@vertices[1,]
#	point2<-a@vertices[45,]
#	origin=c(0,0,0)

	#triangle on the plane
	rad<-dist(rbind(point1, origin), method="euclidean")
	tempor<-.Call('icosa_GreatCircle_', PACKAGE = 'icosa', coord1=point1, coord2=point2, origin=origin, breaks=3, pi=pi)
	
	u<-tempor[2,]-tempor[1,]
	v<-tempor[3,]-tempor[1,]
	
	cp<-c(u[2]*v[3]-u[3]*v[2], u[3]*v[1]-u[1]*v[3], u[1]*v[2]-u[2]*v[1])
	
	
	pointOnPerp<-cp/sqrt(cp[1]^2+cp[2]^2+cp[3]^2)*rad
	
	tempor2<-.Call('icosa_GreatCircle_', PACKAGE = 'icosa', coord1=tempor[1,], coord2=pointOnPerp, origin=origin, breaks=breaks, pi=pi)
	return(tempor2)
}

#function to rotate a single point
rotateOnePoint<-function(coords, angles,origin)
{
	#coords<-c(0,1,0)
	#angles<-c(pi/2,pi/2,pi)
	
	#the rotation matrix
	rotMat<-function(theta)
	{
		mat<-matrix(NA,ncol=2,nrow=2)
		mat[1,1]<-cos(theta)
		mat[1,2]<--sin(theta)
		mat[2,1]<-sin(theta)
		mat[2,2]<-cos(theta)
		return(mat)
	}
	
	#location vector
	locVec<-coords-origin
			
	#first rotation
	#around x
	xMat<-matrix(locVec[2:3],ncol=1, nrow=2)
	xMat<-rotMat(angles[1])%*%xMat
	locVec<-c(locVec[1],as.numeric(xMat))
	
	#second rotation
	yMat<-matrix(locVec[c(1,3)],ncol=1, nrow=2)
	yMat<-rotMat(angles[2])%*%yMat
	locVec<-c(yMat[1], locVec[2],yMat[2])
	
	#third rotation
	zMat<-matrix(locVec[c(1,2)],ncol=1, nrow=2)
	zMat<-rotMat(angles[3])%*%zMat
	locVec<-c(zMat[1:2], locVec[3])
	
	return(locVec)

}
	
# function to create random points on the sphere
#' Random point generation on the surface of a sphere
#' 
#' This function will create a predefined number of points randomly distributed
#' on the surface of a sphere with a given radius.
#' 
#' The function uses a three dimension normal distribution to generate the points.
#' These get projected to the surface of the sphere.
#' 
#' @param n The number of random points to be created.
#' 
#' @param radius The radius of the sphere
#' 
#' @param origin The center of the sphere (XYZ coordinates).
#' 
#' @param output The coordinate system of the new points. Can either be 
#'	\code{"cartesian"} for XYZ coordiates or \code{"polar"} for spherical, 
#'	longitude-latitudes coordinates.
#'
#' @return A 3-column (XYZ) or a 2-column (long-lat) numeric matrix.
#' 
#' @examples
#'	randomPoints <- rpSphere(20000)
#'	points3d(randomPoints)
#' 
#' @export
rpsphere <- function(n=1, output="cartesian", radius=authRadius, origin=c(0,0,0)){
	if(!is.numeric(radius) |
	length(radius)!=1) stop("Invalid input for argument \'radius\'.")
	
	if(!is.numeric(n) |
	length(n)!=1) stop("Invalid input for argument \'n\'.")

	if(!is.numeric(origin) |
	length(origin)!=3) stop("Invalid input for argument \'origin\'.")
	
	
	if(!output%in%c("polar", "cartesian")) 
	
	stop("Invalid input for argument \'output\'.")
		#random variables
		x1 <- rnorm(n, 0, 1)
		y1 <- rnorm(n, 0, 1)
		z1 <- rnorm(n, 0, 1)
		origPoints<-cbind(x1,y1,z1)
	
	# location vectors
	vectors<-origPoints
	vectors[,1]<-origPoints[,1]
	vectors[,2]<-origPoints[,2]
	vectors[,3]<-origPoints[,3]
	
	# distances from the origin
	dists<-sqrt(vectors[,1]^2+vectors[,2]^2+vectors[,3]^2)
	
	#project the point to the sphere
	newPoints<-origPoints
	newPoints[,1]<-origPoints[,1]*radius/dists
	newPoints[,2]<-origPoints[,2]*radius/dists
	newPoints[,3]<-origPoints[,3]*radius/dists
		
	# column names
	colnames(newPoints)<-c("x", "y", "z")
	
	#outputs
	if(output=="polar"){
		result<-CarToPol(newPoints, norad=T, origin=origin)
		colnames(result) <- c("long", "lat")
	}else{
		result<-newPoints
		result[,1] <- result[,1]+origin[1]
		result[,2] <- result[,2]+origin[2]
		result[,3] <- result[,3]+origin[3]
	}
	
	return(result)
}



# small, fast utility function for the lookup of vertices (used in lookup!)
whichVertices<-function(vertices, data){
	# result if no vertex found
	vertIndex<-NULL
	
	#the only total check 
	ctrl1<-data[,1]%in%vertices[,1]
	
	#first coordinate match
	if(sum(ctrl1)>0){
		datSub<-data[ctrl1,,drop=FALSE]
		indSub<-which(ctrl1)
		ctrl2<-datSub[,2]%in%vertices[,2]
		
		#second coordinate match too
		if(sum(ctrl2)>0){
			indSub2<-indSub[ctrl2]
			datSub2<-datSub[ctrl2,,drop=FALSE ]
			ctrl3<-datSub2[,3]%in%vertices[,3]
			
			#third matches as well: vertex!
			if(sum(ctrl3)>0){
				vertIndex<-indSub2[ctrl3]
			}
		}
	
	}

	return(vertIndex)
}
