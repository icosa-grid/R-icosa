#applications and all that


#function to rotate the grid - S4
# some basic rotation is probably necessary to avoid most systematic
#	setGeneric(
#		name="rotate",
#		def=function(obj,...){
#			standardGeneric("rotate")
#		}
#	
#	)

#' Rotation method of trigrid and hexagrid objects
#'
#' @rdname rotate-methods
# ' @aliases rotate, trigrid-method		
#' @exportMethod rotate
setMethod(	
	f="rotate",
	signature="trigrid",
	definition= function(x, angles="random", pivot=NA){
		#origin<-F
		#obj<-grid
		#angles<-c(0.15,0.15,0.15)
	
		if(sum(angles=="random"))
		{
			angles<-c(runif(3,0,2*pi))
		
		}
		if(!is.na(pivot)){
			if(length(pivot!=3) | !is.numeric(pivot)){
				stop("Invalid pivot point coordinates.")
				
			}else{
				orig<-pivot
			}
		
		}else{
			orig<-x@center	
		}
		
		if(suppressWarnings(!is.na(x@sp))){
			message("Please rerun newsp() to regenerate the 2d representation!")
		}
		
		
		# rotate the points
			vertices<-t(apply(x@vertices, 1, rotateOnePoint, angles=angles, origin=orig))
			colnames(vertices)<-c("x","y","z")
		
		#do the same for the face centers
			faceCenters<-t(apply(x@faceCenters, 1, rotateOnePoint, angles=angles, origin=orig))
			colnames(faceCenters)<-c("x","y","z")
		
		# skeleton
			verticesSkel<-t(apply(x@skeleton$v, 1, rotateOnePoint, angles=angles, origin=orig))
			colnames(verticesSkel)<-c("x","y","z")
		
		# add the new, rotated tables to the original object's copy
			x@vertices<-vertices
			x@faceCenters<-faceCenters
			x@skeleton$v<-verticesSkel
		
		# in case the trigrid is a hexagrid too
		if(class(x)=="hexagrid"){
			plotV<-t(apply(x@skeleton$plotV, 1, rotateOnePoint, angles=angles, origin=orig))
			colnames(plotV)<-c("x","y","z")
			x@skeleton$plotV <- plotV
		
		}
		
		# update the orientation
		x@orientation <- x@orientation+angles

		return(x)
		
	}
)

#' Grid orientation
#' 
#' @name orientation
#' 
#' @exportMethod orientation
#' 
#' @rdname orientation-methods
setGeneric(
	name="orientation",
	package="icosa",
	def=function(gridObj,...){
		standardGeneric("orientation")
	}
)

#' @rdname orientation-methods
# ' @aliases orientation, trigrid-method	
setMethod(
	"orientation",
	signature="trigrid",
	definition=function(gridObj,display="deg",...){
		if(display=="rad"){
			names(gridObj@orientation)<-c("x (rad)", "y (rad)", "z (rad)")
			return(gridObj@orientation)
		}
		if(display=="deg"){
			names(gridObj@orientation)<-c("x (deg)", "y (deg)", "z (deg)")
			return(gridObj@orientation/pi*180)
			
		}
	
	}
	
)

#' Grid orientation
#' 
#' @name orientation<-
#' 
#' @exportMethod orientation<-
#' 
#' @rdname orientation-methods
setGeneric(
	name="orientation<-",
	def=function(gridObj,value){
		standardGeneric("orientation<-")
	}
	
)
	

setReplaceMethod(
	"orientation",
	signature="trigrid",
	definition=function(gridObj, value){
		gridObj<-rotate(gridObj, value)
		return(gridObj)
	
	}
)


#get the neigbouring faces
setGeneric(
		name="NeighboursOfOneFace",
		def=function(gridObj,...){
			standardGeneric("NeighboursOfOneFace")
		}
	
	)
		
	


setGeneric(
	name="neighbours",
	def=function(gridObj,...){
		standardGeneric("neighbours")
	}
)

setMethod(
	"neighbours",
	signature="trigrid",
	definition=function(gridObj,faceset, method="nopoint"){
		all<-sapply(faceset, NeighboursOfOneFace, gridObj=gridObj, method=method)
		return(unique(as.character(all)))
		
	}
)


#' Lengths of grid edges
#' 
#' This function will return the length of all edges in the specified grid object.
#' 
#' @name edgelength
#' @param gridObj A \code{trigrid} or \code{hexagrid} class object. 
#' 
#' @param output Characater value, the type of the output. \code{"distance"} will give back the distance
#'	in the metric that was fed to the function in the coordinates or the radius.
#'	\code{"deg"} will output the the distance in degrees, \code{"rad"} will do
#'	so in radians.
#' 
#' @examples
#' 	g <- trigrid(3)
#' 	edges <- edgelength(g, output="deg")
#' 	edges
#' 
#' @return A named numeric vector.
#' 	
#' @exportMethod edgelength
#' @rdname edgelength-methods
setGeneric(
	name="edgelength",
	def=function(gridObj,...){
		standardGeneric("edgelength")
	}

)

#' @rdname edgelength-methods
# ' @aliases edgelength, trigrid-method	
setMethod(
	"edgelength", 
	signature="trigrid",
	definition=function(gridObj, output="distance"){
		if(!output%in%c("distance", "rad", "deg")) stop("Invalid distance method.")
		v<-gridObj@skeleton$v
		e<-gridObj@skeleton$e
		
		if(output=="distance"){
			met<-1
		}else{
			met<-0
		}
		sizes<-  .Call('icosa_edges_', PACKAGE = 'icosa', v, e, origin=as.integer(gridObj@center), method=as.logical(met))
		
		names(sizes)<-rownames(gridObj@edges)
		
		if(output=="deg") sizes<-sizes/pi*180
		
		return(sizes)
		
	}
)


#' Areas of grid cell surfaces
#' 
#' This function will return the areas of all cells in the specified grid object.
#' 
#' @name surfacearea
#' @param gridObj A \code{trigrid} or \code{hexagrid} object. 
#' 
#'	in the metric that was fed to the function in the coordinates or the radius.
#'	\code{"deg"} will output the the distance in degrees, \code{"rad"} will do
#'	so in radians.
#' 
#' @examples
#' 	g <- trigrid(3)
#' 	surfaces <- surfacearea(g)
#' 	surfaces
#' 
#' @return A named numeric vector.
#' 	
#' @rdname surfacearea-methods
#' @exportMethod surfacearea
setGeneric(
	name="surfacearea",
	package="icosa",
	def=function(gridObj,...){
		standardGeneric("surfacearea")
		
	}
)

#' @rdname surfacearea-methods
# ' @aliases surfacearea, trigrid-method	
setMethod(
	"surfacearea", 
	signature="trigrid", 
	def=function(gridObj){
		# get the highest resolution faces
		newF <- gridObj@skeleton$f[as.logical(gridObj@skeleton$aF),1:3]
		v <- gridObj@skeleton$v
		
		# call the surface calculation function
		surfInner <-  .Call('icosa_spherTriSurfs', 
			PACKAGE = 'icosa', 
			v=v, 
			f=newF, 
			origin=gridObj@center, 
			pi=pi
		)
		
		# reorganize the faces: outer representation
		ord<-gridObj@skeleton$aF[as.logical(gridObj@skeleton$aF)]
		
		surfOuter<-surfInner
		surfOuter[ord]<- surfInner
		
		names(surfOuter) <- rownames(gridObj@faces)
		
		return(surfOuter)
	}
)

#' @rdname surfacearea-methods
# ' @aliases surfacearea, hexagrid-method
setMethod(
	"surfacearea", 
	signature="hexagrid", 
	def=function(gridObj){
		# get the highest resolution faces
		newF <- gridObj@skeleton$f[as.logical(gridObj@skeleton$aSF),1:3]
		v <- gridObj@skeleton$v
		
		# call the surface calculation function
		surfInner <-  .Call('icosa_spherTriSurfs', 
			PACKAGE = 'icosa', 
			v=v, 
			f=newF, 
			origin=gridObj@center, 
			pi=pi
		)
		
		# the subfaces belong to these face IDs in the outer representation
		aS<-gridObj@skeleton$aSF[as.logical(gridObj@skeleton$aSF)]
		
		# calculate the sums of all subface areas in a face, and order them
		doubleSurf<-tapply(INDEX=aS, X=surfInner, sum)
		
		# each subface occurs two times in the f matrix, divide area by 2
		singleSurf <- doubleSurf/2
		
		# augment the names attributes
		names(singleSurf)<- paste("F", names(singleSurf), sep="")
		
		return(singleSurf)
	}
)


			
#wrapper function to get n number of random points from a set of faces entire grid

#get a set of random points from the triangular face
RandPoints.trigrid<-function(gridObj, n, facenames, res){
#	gridObj<-grid
#	n<-50
	
	if(is.null(facenames))
	{
		facenames<-rownames(gridObj$faces)
	}
   
   # in case it does not matter where the points are from
    if(length(n)==1){
        sourceFaces<-sample(facenames,n,replace=T)
    }else{
        # in case it specified how many points should come from a single face
        if(length(n)==length(facenames)){
            sourceFaces<-NULL
            for(i in 1:length(facenames)){
                sourceFaces<-c(sourceFaces,sample(facenames[i],n[i],replace=T))
            }
        }else{
            stop("The length of the vector containing the number of points to be \n  sampled from a face does not equal the number of specified faces.")
        }
    }
	#get the data random face
	sourcePoints<-gridObj$faces[sourceFaces,]
	
	randomPoints<-t(apply(sourcePoints,1,RandomPointTriangle,gridObj=gridObj,res=res))
	
	return(randomPoints)
}


#get random points from a hexagrid object
RandPoints.hexagrid<-function(gridObj, n, facenames, res){
#	gridObj<-hexagonal
#	n<-120
	
	if(is.null(facenames))
	{
		facenames<-rownames(gridObj$faces)
	}
   
   # in case it does not matter where the points are from
    if(length(n)==1){
        sourceFaces<-sample(facenames,n,replace=T)
    }else{
        # in case it specified how many points should come from a single face
        if(length(n)==length(facenames)){
            sourceFaces<-NULL
            for(i in 1:length(facenames)){
                sourceFaces<-c(sourceFaces,sample(facenames[i],n[i],replace=T))
            }
        }else{
            stop("The length of the vector containing the number of points to be \n  sampled from a face does not equal the number of specified faces.")
        }
    }
	#look up the subFaces
    allSubFaces<-gridObj$faces[sourceFaces,]
    
    # auxilliary function to get a random subface
    GetOneSubFace<-function(charVec){
        # omit NA values
        charVec <- charVec[!is.na(charVec)]
        return(sample(charVec, 1))
    }
    
    sourceSubFaces <- apply(allSubFaces, 1, GetOneSubFace)
    
    sourcePoints<-gridObj$subFaces[sourceSubFaces,]
	
    #get a temporary grid copy that contain the vertices that are necessary
    gridObj$vertices<-gridObj$subVertices
    
	randomPoints<-t(apply(sourcePoints,1,RandomPointTriangle,gridObj=gridObj,res=res))
	
	return(randomPoints)
    
}


	
#function to get a random point from a spherical triangle in an object	
RandomPointTriangle<-function(points, gridObj=grid,res){
#	#test data
#	point1<-grid$faces[1,1]
#	point2<-grid$faces[1,2]
#	point3<-grid$faces[1,3]
#	points<-grid$faces[1,]
#	obj<-grid
#	res<-15
#	origin<-c(0,0,0)
	
	
	#if exact points are specified
	pointCoord1<-gridObj$vertices[points[1],]
	pointCoord2<-gridObj$vertices[points[2],]
	pointCoord3<-gridObj$vertices[points[3],]

	#step 1. choose a random point
	sampPoint<-sample(points,1)
	otherPoints<-points[!points%in%sampPoint]
	
	#cut the two edges at a given resolution
	endPoints1<-SplitEdgeSpherical(sampPoint,otherPoints[1],obj=gridObj, breaks=res,origin=origin)$vertices
	endPoints1<-endPoints1[2:(nrow(endPoints1)-1),]
	
	endPoints2<-SplitEdgeSpherical(sampPoint,otherPoints[2],obj=gridObj, breaks=res,origin=origin)$vertices
	endPoints2<-endPoints2[2:(nrow(endPoints2)-1),]
	
	#get a random slice
	slice<-sample(nrow(endPoints1),1)
	
	#split the the slice at resolution  
	brokenSlice<-SplitArc(endPoints1[slice,],endPoints2[slice,],origin=origin,breaks=res)
	finalPoint<-brokenSlice[sample(2:(nrow(brokenSlice)-1),1),]
	return(finalPoint)
}	

#try the RandomPointTriangle function
#	tempPoints<-grid$vertices[grid$faces[1,],]
#	points3d(tempPoints)
#	for(i in 1:1000){
#		a<-RandomPointTriangle(grid$faces[1,],obj=grid,res=100,origin=origin)
#		points3d(x=a[1],y=a[2],z=a[3],col="green")
#	}
#	
#	OnFace(as.numeric(a),grid,origin)



# Sampling of random points from grid faces
# 
# This function generates a set of random points from the surface of a face on an icosahedral grid.
# 
# The algorithm uses a method similar to tesselation: it breaks one of great circles that form the edges of the face, then selects one point from the great circle between the vertex opposite of the original edge and the previously created point.
# 
# @param n Integer vector containing the number of points to be sampled from the specified surfaces. If it is a single value than it specifies the total number of points.
# If its length equals the number of specified faces in the \code{facenames} argument, it will return the respective number of samples from each face.
# 
# @param facenames A character vector containing the face names that will be sampled. If set to \code{NULL} the entire grid will be sampled.
# 
# @param gridObj The grid that will be sampled, either a \code{trigrid} or \code{hexagrid} object.
# 
# @param res The resolution at which the randomly selected great circles are divided.
# 
# @examples
# # Create a triangular grid
# triangular<-CreateGrid(c(2,2), "tri")
# 
# #get a set of random points
# random<-RandPoints( gridObj=triangular, c(150,40),facenames=c("F12", "F10"),  res=100)
# 
# #plot these in Cartesian space
# PlotGrid3d(triangular, "edges", col="blue")
# points3d(x=random[,1],y=random[,2],z=random[,3])
# 
RandPoints<-function(gridObj, n, facenames=NULL, res=100){
	UseMethod("RandPoints",gridObj)
}




## wrapper function around the OccupiedFaces generic, to get the occupied grid cells. return out a facelayer object
#export!
#' Face occupied by the specified object
#'
#' This function will return a facelayer object showing which faces are occupied by the input object.
#'
#' This is a wrapper function on the OccupiedFaces methods that are specific to grid and input data. The function creates a link between the facelayer and the relevant grid.
#'
#' @param gridObj a trigrid or hexagrid object.
#' 
#' @param data the queried data.
#'
#' @param ... arguments passed to the class specific methods
#'
#' @return returns a facelayer object
#'
#' @export	
occupied  <- function(gridObj, data,...){
	
	# do spatial transformation if a CRS is present
	if(.hasSlot(data, "proj4string")){
		# and only if it is not NA
		if(!is.na(data@proj4string)){
			data<-spTransform(data, gridObj@proj4string)
		}
	}
	
	#exectue the appropriate searching procedure
	boolVec<-OccupiedFaces(gridObj, data,...)
	
	# construct a facelayer
	endObj<-facelayer(gridObj)
	
	#outer ordering for the hexagrid
	translNum<-which(boolVec)
		
	# replace
	endObj@values<-FALSE
	endObj@values[translNum]<-TRUE

	# get the name of the grid - 
	endObj@grid<-deparse(substitute(gridObj))
	return(endObj)

}



#OccupiedFaces
#returns a boolean for all the faces (ordered as the internal representation in skeleton$f)
#use this when you do not need to know which face contains which point
setGeneric(
		name="OccupiedFaces",
		def=function(gridObj,data,...){
			standardGeneric("OccupiedFaces")
		}
	
	)
	

# occupied method for the trigrid v5.1
# this version uses my own c++ function for point in tetrahedron testing, expanded with
# hierarchical searching
setMethod(
	"OccupiedFaces", 
	signature=c("trigrid", "matrix"),
	definition=function(gridObj, data, borders=NA){
	if(ncol(data)==3){
	}else{
		if(ncol(data)==2){
			#convert the points to Cartesian if necessary
			data<-PolToCar(data, radius=gridObj@r, origin=gridObj@center)
		}
	}
	
	
	#the tetrahedron algorithm does not find vertices
	if(!is.na(borders)){
		if(borders!="random") stop("Invalid borders argument.")
	}
	
	# get rid of the vertices to avoid errors
		if(is.na(borders)){
			vertInd<-whichVertices(gridObj@vertices, data)
	
			#replace vertices with NAs
			data[vertInd,]<-NA
			
			# does the date include NAs?
			boolResultNoNA<-!is.na(data[,1]) & !is.na(data[,2]) & !is.na(data[,3]) 
			data<-data[boolResultNoNA,, drop=FALSE]
	
		}
		
	#project the coordinates out from the origin
	#access the skeleton of the grid
		v<-gridObj@skeleton$v*1.5
		f<-gridObj@skeleton$f[,1:3]
		origin<-gridObj@center
	
		d<-gridObj@div
		
	#organize vertices to the linear coordinate + add 1s for the determinants
		#written with C++ for speed
		vtsBig<- .Call('icosa_xyz1xyz1xyz1xyz1_', PACKAGE = 'icosa', v, f)
		
		
	#check whether the point is one of the vertices!!!!! here
		
	#the queried data in a similar linear format x*n,y*n, z*n
		qrs<-.Call('icosa_xyz1', PACKAGE = 'icosa', data)
		
		nQrs<-as.integer(nrow(data))
				
			
		# allocate some memory to the results vector 
		queryIndex<-rep(0, nrow(data)*6)
		faceIndex<-rep(0, nrow(data)*6)
			
	#invoke the C function
	#written with direct C object manipulation to evade speed loss with copying
	Output = .C("locateTriangle_",
		allVertices=as.double(vtsBig),
		divs=as.integer(d),
		nDivs=as.integer(length(d)),
		queries=as.double(qrs), 
		nQrs=as.integer(nQrs),
		queryIndex=as.integer(queryIndex),
		faceIndex=as.integer(faceIndex),
		offset=as.integer(rep(0,length(d)+1)),
		faceContainer=as.integer(rep(0, max(d)+1)),
		foundMiddle=as.integer(rep(0,12)),
		tempF=as.integer(rep(0, max(d)+1))
	)
	
	fi<-Output$faceIndex+1
	qi<-Output$queryIndex+1
	
	need <- max(which(nQrs==qi))
	
	fi <- fi[1:need]
	qi <- qi[1:need]
	
	# multiple results?
	tQi<-table(qi)
	boolMulti <- tQi>1
	if(sum(boolMulti)>0){
	
		levs<-as.numeric(names(tQi)[boolMulti])
		
		# good as it is:
		goodIndex<-qi[!qi%in%levs]
		goodFace<-fi[!qi%in%levs]
		if(is.na(borders)){
			for (i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, NA)
			}
		}else{
			for(i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, sample(fi[qi==levs[i]],1))
			
			}
		}
			
		# loop through
		fi<-0
		qi<-0
		fi[goodIndex]<-goodFace
		qi[goodIndex]<-goodIndex
	}
	
	logPresent<-1:nrow(gridObj@faces)%in%fi
	activeFaces<-gridObj@skeleton$aF[(Output$offset[(length(Output$offset)-1)]+1):length(gridObj@skeleton$aF)]
	
	values<-activeFaces&logPresent
	
	translNum<-gridObj@skeleton$aF[gridObj@skeleton$offsetF+which(values)]
	
	newValues<-rep(FALSE, nrow(gridObj@faces))
	newValues[translNum] <- TRUE
	
	return(newValues)
	
	}


#	#check the results
#	plot3d(gridObj, sphere=6050)
#	points3d(data[1:5000,], col="red")
#	
#	temp<-levels(factor(fi[1:5000]))
#	
#	sG<-subset(gridObj, paste("F", temp,sep=""))
#	faces3d(sG, col="blue")
	
)


# for spatial points
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "SpatialPoints"),
	definition=function(gridObj, data, borders=NA){
		# basic method for matrices
		OccupiedFaces(gridObj, data@coords)
	}
)


# for polygon occupation development
setMethod(
	"OccupiedFaces", 
	signature=c("trigrid", "Polygon"),
	definition=function(gridObj, data, borders=NA){
		#get the number of faces occupied by the line
			lin<-data@coords
			lin2<-.Call('icosa_Refine2d_', PACKAGE = 'icosa', lin, 1000)
			nLine<-sum(OccupiedFaces(gridObj,lin2))
			
		# the number of regular sampling points have a relationship with that
		#5 is arbitrary
			n<-nLine*nLine*5
			
		# the SpatialPoints method
		allSample<-spsample(data, type="regular", n=n)
		fLayer<-OccupiedFaces(gridObj, allSample)
		return(fLayer)
	}
)

#for Polygons 
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "Polygons"),
	definition=function(gridObj, data, borders=NA,n=10000,...){
		#faces on the line
		coordLine<-lines3d(data, plot=F)
		coordLine<-coordLine[!is.na(coordLine[,1]),]
		#look these up
		lineFaces<-OccupiedFaces(gridObj, coordLine)
		#get all the sampling points
		all<-spsample(data, type="regular", n=n)

		inFaces<-OccupiedFaces(gridObj, all@coords, borders=borders)
		fl <- inFaces | lineFaces
		return(fl)
	}
)

#for SpatialLines 
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "SpatialLines"),
	definition=function(gridObj, data, borders=NA,f=5){
		# increase resolution
		data<-linIntCoords(data, res=f)
		
		# get the coordinates
		coords<-lines3d(data, plot=T)
		
		#get rid of NAs
		coords<-coords[!is.na(coords[,1]),]
		
		# the faces occupied by the line
		occupiedByLine<-OccupiedFaces(gridObj, coords, borders=borders)
		
		return(occupiedByLine)
	}
)
		
#for SpatialPolygons 
# v. 3.0
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "SpatialPolygons"),
	definition=function(gridObj, data, borders=NA){
		
		#faces on the line
		coordLine<-lines3d(data, plot=F)
		coordLine<-coordLine[!is.na(coordLine[,1]),]
		#look these up
		lineFaces<-OccupiedFaces(gridObj, coordLine)
		
		# create a raster from the SpatialPolygons
		r <-raster()
		
		# set the resolution to that of the grid
		res(r)<-min(edgelength(gridObj, output="deg"))/4
		
		#rasterize it
		data<-rasterize(wo,r)
				
		# use the OccupiedFaces method of the raster
		inFaces<-OccupiedFaces(gridObj, data, borders=borders)
		fl <- inFaces | lineFaces
		return(fl)
	}
)

#for SpatialPolygonsDataFrame
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "SpatialPolygonsDataFrame"),
	definition=function(gridObj, data, borders=NA){
		temp<-as(data,"SpatialPolygons")
		fl <- OccupiedFaces(gridObj, temp, borders=borders)
		return(fl)
	}
)


# for spatial points
setMethod(
	"OccupiedFaces",
	signature=c("trigrid", "RasterLayer"),
	definition=function(gridObj, data, borders=NA){
		resGrid<-mean(edgelength(gridObj,"deg"))
		# if the default resolution of the raster is too coarse for the trigrid
		if(resGrid<(4*res(data)[1]) | resGrid<(4*res(data)[2])){
			#upscale
			r<-data
			res(r)<-resGrid/4
			data<-resample(data, r, "ngb")
		}
		
		xmin<-data@extent@xmin
		xmax<-data@extent@xmax
		ymin<-data@extent@ymin
		ymax<-data@extent@ymax
		
		xres<-res(data)[1]
		yres<-res(data)[2]
		
		xs<-seq(xmin+xres/2, xmax-xres/2,xres)
		ys<-seq(ymax-yres/2, ymin+yres/2,-yres)
		
		x<-rep(xs, length(ys))
		y<-rep(ys, each=length(xs))
		mat<-cbind(x,y)
		
		cells<-locate(gridObj, mat)
		
		occup<-tapply(X=values(data), INDEX=cells, function(x){sum(!is.na(x))})
		occupiedCells<-names(occup)[occup>0]
		
		fl<-rep(FALSE, length(gridObj))
		fl[rownames(gridObj@faces)%in%occupiedCells]<-T
		
		return(fl)
	}
)

################################################################################
# The HEXAGRID
setMethod(
	"OccupiedFaces",
	signature=c("hexagrid","matrix"),
	definition=function(gridObj,data,borders=NA){

		#the tetrahedron algorithm does not find vertices
		if(!is.na(borders)){
			if(borders!="random") stop("Invalid borders argument.")
		}
		
		#data argument
		# which formatting?
		if(ncol(data)==2){
			# transform the two columns
			data<-PolToCar(data, origin=gridObj@center, radius=gridObj@r)
		}
		
		# get rid of the vertices to avoid errors
		if(is.na(borders)){
			vertInd<-whichVertices(gridObj@vertices, data)
	
			#replace vertices with NAs
			data[vertInd,]<-NA
			
			# does the date include NAs?
			boolResultNoNA<-!is.na(data[,1]) & !is.na(data[,2]) & !is.na(data[,3]) 
			data<-data[boolResultNoNA,, drop=FALSE]
	
		}
		
		
		
		#project the coordinates out from the origin
		#access the skeleton of the grid
			v<-gridObj@skeleton$v*1.5
			f<-gridObj@skeleton$f[,1:3]
			origin<-gridObj@center
		
			d<-gridObj@div
			d<-c(d,6)
			
		#organize vertices to the linear coordinate + add 1s for the determinants
			#written with C++ for speed
			vtsBig<- .Call('icosa_xyz1xyz1xyz1xyz1_', PACKAGE = 'icosa', v, f)
			
			
		#check whether the point is one of the vertices!!!!! here
			
		#the queried data in a similar linear format x*n,y*n, z*n
			qrs<-.Call('icosa_xyz1', PACKAGE = 'icosa', data)
			
			nQrs<-as.integer(nrow(data))
					
				
			# allocate some memory to the results vector 
			queryIndex<-rep(-9, nrow(data)*6)
			faceIndex<-rep(0, nrow(data)*6)
				
		#invoke the C function
		#written with direct C object manipulation to evade speed loss with copying
		Output = .C("locateTriangle_",
			allVertices=as.double(vtsBig),
			divs=as.integer(d),
			nDivs=as.integer(length(d)),
			queries=as.double(qrs), 
			nQrs=as.integer(nQrs),
			queryIndex=as.integer(queryIndex),
			faceIndex=as.integer(faceIndex),
			offset=as.integer(rep(0,length(d)+1)),
			faceContainer=as.integer(rep(0, max(d)+1)),
			foundMiddle=as.integer(rep(0,12)),
			tempF=as.integer(rep(0, max(d)+1))
		)
		
		fi<-Output$faceIndex+1
		qi<-Output$queryIndex+1
		
		need <- max(which(nQrs==qi))
		qi <- qi[1:need]
		fi <- fi[1:need]
		
		# multiple results?
		tQi<-table(qi)
		boolMulti <- tQi>1
		if(sum(boolMulti)>0){
		
			levs<-as.numeric(names(tQi)[boolMulti])
			
			# good as it is:
			goodIndex<-qi[!qi%in%levs]
			goodFace<-fi[!qi%in%levs]
			if(is.na(borders)){
				for (i in 1:length(levs)){
					goodIndex<-c(goodIndex, levs[i])
					goodFace<-c(goodFace, NA)
				}
			}else{
				for(i in 1:length(levs)){
					goodIndex<-c(goodIndex, levs[i])
					goodFace<-c(goodFace, sample(fi[qi==levs[i]],1))
				
				}
			}
				
			# loop through
			fi<-0
			qi<-0
	
			fi[goodIndex]<-goodFace
			qi[goodIndex]<-goodIndex
		}
		fiUI<-gridObj@skeleton$aSF[Output$offset[length(d)]+fi]
		
		# add a check whether the point is exactly a facecenter(triangle vertex)
		if(sum(is.na(fiUI))>0){
			mightBeVertex<-data[is.na(fiUI),, drop=F]
			
			#facecenters
			nF<-sum(gridObj@skeleton$f[,4]==-6)/12+2
			
			#distance matrix between points and vertices
			tempDist<-arcdistmat(points1=mightBeVertex, points2=gridObj@skeleton$v[1:nF,])
			
			newFaceInner<-apply(tempDist,1, function(x){
				minimum<-min(x)
				if(minimum<10e-10){
					return(which(x==minimum))
				}else{
					return(NA)
				}
			
			})
			
			fiUI[is.na(fiUI)]<-gridObj@skeleton$aF[newFaceInner]
		}
		
		logPresent<-1:nrow(gridObj@faces)%in%fiUI
		values<-logPresent
		
		return(values)
		
	
	}
)



#' Basic lookup function of coordinates on an icosahedral grid
#'
#' @name locate
#' @return The function returns the cell name where the input coordinate falls.
#' @rdname locate-methods
#' @exportMethod locate
setGeneric(
		name="locate",
		def=function(gridObj,...){
			standardGeneric("locate")
		}
	
	)

# locate method for the trigrid v5.1
# this version uses my own c++ function for point in tetrahedron testing
#' @rdname locate-methods
# ' @aliases locate, trigrid-method	
#' @exportMethod locate
setMethod(
	"locate", 
	signature="trigrid",
	definition=function(gridObj, data, borders=NA, output="ui"){
	
	#the tetrahedron algorithm does not find vertices
	if(!is.na(borders)){
		if(borders!="random") stop("Invalid borders argument.")
	}
	if(!output%in%c("ui", "skeleton")){
		stop("Invalid value for output argument.")
	}
	
	# for the SpatialPoints
	if(class(data)=="SpatialPoints"){
		# if it has a proj4
		if(.hasSlot(data, "proj4string")){
			# and it's not NA
			if(!is.na(data@proj4string)){
				data<-spTransform(data, gridObj@proj4string)@coords
			}
		}
	}
	
	#data argument
	# which formatting?
	if(ncol(data)==2){
	
		# transform the two columns
		data<-PolToCar(data, origin=gridObj@center, radius=gridObj@r)
	}
	
	# get rid of the vertices to avoid errors
	if(is.na(borders)){
		vertInd<-whichVertices(gridObj@vertices, data)
	
		#replace vertices with NAs
		data[vertInd,]<-NA
	
	}
	
	# does the date include NAs?
	boolResultNoNA<-!is.na(data[,1]) & !is.na(data[,2]) & !is.na(data[,3]) 
	data<-data[boolResultNoNA,, drop=FALSE]
	
	
	#project the coordinates out from the origin
	#access the skeleton of the grid
		v<-gridObj@skeleton$v*1.5
		f<-gridObj@skeleton$f[,1:3]
		origin<-gridObj@center
	
		d<-gridObj@div
		
	#organize vertices to the linear coordinate + add 1s for the determinants
		#written with C++ for speed
		vtsBig<- .Call('icosa_xyz1xyz1xyz1xyz1_', PACKAGE = 'icosa', v, f)
		
		
	#check whether the point is one of the vertices!!!!! here
		
	#the queried data in a similar linear format x*n,y*n, z*n
		qrs<-.Call('icosa_xyz1', PACKAGE = 'icosa', data)
		
		nQrs<-as.integer(nrow(data))
				
			
		# allocate some memory to the results vector 
		queryIndex<-rep(-9, nrow(data)*12)
		faceIndex<-rep(-9, nrow(data)*12)
		foundMiddle<-rep(0, nrow(data)*12)
		faceContainer<-rep(0, max(d)+1)
		offset<-rep(0,length(d)+1)
		tempF<-rep(0, max(d)+1)
			
	#invoke the C function
	#written with pass by reference object manipulation to evade speed loss with copying
	Output = .C("locateTriangle_",
		allVertices=as.double(vtsBig),
		divs=as.integer(d),
		nDivs=as.integer(length(d)),
		queries=as.double(qrs), 
		nQrs=as.integer(nQrs),
		queryIndex=as.integer(queryIndex),
		faceIndex=as.integer(faceIndex),
		offset=as.integer(offset),
		faceContainer=as.integer(faceContainer),
		foundMiddle=as.integer(foundMiddle),
		tempF=as.integer(tempF)
	)
	
	fi<-Output$faceIndex+1
	qi<-Output$queryIndex+1
	
	# in case no values are passed to the function
	if(nQrs==0){
		fi<-NA
		qi<-0
	}
	
	need <- max(which(nQrs==qi))
	qi <- qi[1:need]
	fi <- fi[1:need]
	
	# multiple results?
	tQi<-table(qi)
	boolMulti <- tQi>1
	if(sum(boolMulti)>0){
	
		levs<-as.numeric(names(tQi)[boolMulti])
		
		# good as it is:
		goodIndex<-qi[!qi%in%levs]
		goodFace<-fi[!qi%in%levs]
		if(is.na(borders)){
			for (i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, NA)
			}
		}else{
			for(i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, sample(fi[qi==levs[i]],1))
			
			}
		}
			
		# loop through
		fi<-0
		qi<-0
		fi[goodIndex]<-goodFace
		qi[goodIndex]<-goodIndex
		
	}
	if(output=="ui"){
		# translate the inner C representation to the UI
		fiUI<-gridObj@skeleton$aF[gridObj@skeleton$offsetF+fi]
		
		options(scipen=999)
		fiUI[!is.na(fiUI)]<-paste("F", fiUI[!is.na(fiUI)], sep="")
		options(scipen=0)
		resVec<-rep(NA, length(boolResultNoNA))
		resVec[boolResultNoNA]<-fiUI
		
		return(resVec)
	}
	if(output=="skeleton"){
		resVec<-rep(NA, length(boolResultNoNA))
		resVec[boolResultNoNA]<-fiUI
		
		return(resVec)
	}
	
#	#check the results
#	plot3d(gridObj, sphere=6050)
#	points3d(data[1:5000,], col="red")
#	
#	temp<-levels(factor(fi[1:5000]))
#	
#	sG<-subset(gridObj, paste("F", temp,sep=""))
#	faces3d(sG, col="blue")
	}
)

# locate method for the hexagrid v5.1
# this version uses my own c++ function for point in tetrahedron testing
#' @rdname locate-methods
# ' @aliases locate, hexagrid-method
#' @exportMethod locate
setMethod(
	"locate", 
	signature="hexagrid",
	definition=function(gridObj, data, borders=NA, output="ui"){
	
	#the tetrahedron algorithm does not find vertices
	if(!is.na(borders)){
		if(borders!="random") stop("Invalid borders argument.")
	}
	if(!output%in%c("ui", "skeleton")){
		stop("Invalid value for output argument.")
	}
	
	if(is.data.frame(data)){
		data <- as.matrix(data)
	}
	
	# for the SpatialPoints
	if(class(data)=="SpatialPoints"){
		# if it has a proj4
		if(.hasSlot(data, "proj4string")){
			# and it's not NA
			if(!is.na(data@proj4string)){
				data<-spTransform(data, gridObj@proj4string)@coords
			}
		}
	}
	
	#data argument
	# which formatting?
	if(ncol(data)==2){
		# transform the two columns
		data<-PolToCar(data, origin=gridObj@center, radius=gridObj@r)
	}
	
	# get rid of the vertices to avoid errors
	if(is.na(borders)){
		vertInd<-whichVertices(gridObj@vertices, data)
	
		#replace vertices with NAs
		data[vertInd,]<-NA
	
	}
	
	# does the data include NAs?
	boolResultNoNA<-!is.na(data[,1]) & !is.na(data[,2]) & !is.na(data[,3]) 
	data<-data[boolResultNoNA,, drop=FALSE]
	
	#project the coordinates out from the origin
	#access the skeleton of the grid
		v<-gridObj@skeleton$v*1.5
		f<-gridObj@skeleton$f[,1:3]
		origin<-gridObj@center
	
		d<-gridObj@div
		d<-c(d,6)
		
	#organize vertices to the linear coordinate + add 1s for the determinants
		#written with C++ for speed
		vtsBig<- .Call('icosa_xyz1xyz1xyz1xyz1_', PACKAGE = 'icosa', v, f)
		
		
	#check whether the point is one of the vertices!!!!! here
		
	#the queried data in a similar linear format x*n,y*n, z*n
		qrs<-.Call('icosa_xyz1', PACKAGE = 'icosa', data)
		
		nQrs<-as.integer(nrow(data))
				
			
		# allocate some memory to the results vector 
		queryIndex<-rep(-9, nrow(data)*6)
		faceIndex<-rep(0, nrow(data)*6)
			
	#invoke the C function
	#written with direct C object manipulation to evade speed loss with copying
	Output = .C("locateTriangle_",
		allVertices=as.double(vtsBig),
		divs=as.integer(d),
		nDivs=as.integer(length(d)),
		queries=as.double(qrs), 
		nQrs=as.integer(nQrs),
		queryIndex=as.integer(queryIndex),
		faceIndex=as.integer(faceIndex),
		offset=as.integer(rep(0,length(d)+1)),
		faceContainer=as.integer(rep(0, max(d)+1)),
		foundMiddle=as.integer(rep(0,12)),
		tempF=as.integer(rep(0, max(d)+1))
	)
	
	fi<-Output$faceIndex+1
	qi<-Output$queryIndex+1
	
	# in case no values are passed to the function
	if(nQrs==0){
		fi<-NA
		qi<-0
	}
	
	need <- max(which(nQrs==qi))
	qi <- qi[1:need]
	fi <- fi[1:need]
	
	
	# multiple results?
	tQi<-table(qi)
	boolMulti <- tQi>1
	if(sum(boolMulti)>0){
	
		levs<-as.numeric(names(tQi)[boolMulti])
		
		# good as it is:
		goodIndex<-qi[!qi%in%levs]
		goodFace<-fi[!qi%in%levs]
		if(is.na(borders)){
			for (i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, NA)
			}
		}else{
			for(i in 1:length(levs)){
				goodIndex<-c(goodIndex, levs[i])
				goodFace<-c(goodFace, sample(fi[qi==levs[i]],1))
			
			}
		}
			
		# loop through
		fi<-0
		qi<-0

		fi[goodIndex]<-goodFace
		qi[goodIndex]<-goodIndex
	}
	
	if(output=="ui"){

		# translate the inner C representation to the UI
		fiUI<-gridObj@skeleton$aSF[Output$offset[length(d)]+fi]
		
		# add a check whether the point is exactly a facecenter(triangle vertex)
		if(sum(is.na(fiUI))>0){
			mightBeVertex<-data[is.na(fiUI),, drop=F]
			
			#facecenters
			nF<-sum(gridObj@skeleton$f[,4]==-6)/12+2
			
			#distance matrix between points and vertices
			tempDist<-arcdistmat(points1=mightBeVertex, points2=gridObj@skeleton$v[1:nF,])
			
			newFaceInner<-apply(tempDist,1, function(x){
				minimum<-min(x)
				if(minimum<10e-10){
					return(which(x==minimum))
				}else{
					return(NA)
				}
			
			})
			
			fiUI[is.na(fiUI)]<-gridObj@skeleton$aF[newFaceInner]
		}
		
		# add the labels
		#temporarily supress scientific notation
		options(scipen=999)
		fiUI[!is.na(fiUI)]<-paste("F", fiUI[!is.na(fiUI)], sep="")
		options(scipen=0)
		
		resVec<-rep(NA, length(boolResultNoNA))
		resVec[boolResultNoNA]<-fiUI
		
		
		
		return(resVec)
	}
	if(output=="skeleton"){
		fiInner<-gridObj@skeleton$f[Output$offset[length(d)]+fi,1]
		
		# add a check whether the point is exactly a facecenter(triangle vertex)
		if(sum(is.na(fiInner))>0){
			mightBeVertex<-data[is.na(fiInner),, drop=F]
			
			#facecenters
			nF<-sum(gridObj@skeleton$f[,4]==-6)/12+2
			
			#distance matrix between points and vertices
			tempDist<-arcdistmat(mightBeVertex, gridObj@skeleton$v[1:nF,])
			
			newFaceInner<-apply(tempDist,1, function(x){
				minimum<-min(x)
				if(minimum<10e-10){
					return(which(x==minimum))
				}else{
					return(NA)
				}
			
			})
			
			fiInner[is.na(fiInner)]<-newFaceInner-1
		}
		
		
		resVec<-rep(NA, length(boolResultNoNA))
		resVec[boolResultNoNA]<-fiInner
		
		return(resVec)
	}
	
#	#check the results
#	plot3d(gridObj, sphere=6050)
#	points3d(data[1:5000,], col="red")
#	
#	temp<-levels(factor(fi[1:5000]))
#	
#	sG<-subset(gridObj, paste("F", temp,sep=""))
#	faces3d(sG, col="blue")
	}
)


#' Position of face centers and vertices on a grid
#' 
#' This function will retrieve the position of a vertex or a face on a \code{hexagrid} or \code{trigrid} object.
#' 
#' Vertex and face names can be mixed in a single \code{names} argument.
#' 
#' @param gridObj a \code{hexagrid} or \code{trigrid} object.
#' 
#' @param names A (character) vector of the names that are to be looked up.
#' 
#' @param output The coordinate system in which the names are to be shown: use \code{"polar"} for longitude-latitude and \code{"cartesian"} for XYZ output.
#' 
#' @return A numerical matrix.
#' 
#' @examples
#' 	g <- trigrid(c(4,4))
#' 	pos(g, c("F2", "P6", "dummyname"))
#' 
#' 
#' @export
pos<-function(gridObj, names, output="polar"){
	
	if(!class(gridObj)%in%c("trigrid", "hexagrid")) stop("Invalid gridObj argument.")
	if(!output%in%c("polar", "cartesian")) stop("Invalid output argument.")
	
	names<-as.character(names)
	
	#facecenters
	fBool<-names%in%rownames(gridObj@faces)
	fcs<-gridObj@faceCenters[names[fBool],]

	#vertices
	vBool<-names%in%rownames(gridObj@vertices)
	vs<-gridObj@vertices[names[vBool],]
	
	#result
	res<-matrix(NA, nrow=length(names), ncol=3)
	
	res[fBool,] <- fcs
	res[vBool,] <- vs
	
	if(output=="cartesian"){
		rownames(res)<-names
		colnames(res)<-c("x","y", "z")
	}
	
	if(output=="polar"){
		res<-CarToPol(res, norad=T, origin=gridObj@center)
		rownames(res)<-names
		colnames(res)<-c("long", "lat")
	}
	return(res)
}


#' @exportMethod resample
setMethod(
	"resample",
	signature=c("Raster", "trigrid"),
	definition=function(x,y, method="ngb", up=1, na.rm=T){
		
		
		# copy the raster
		x2<-x
		
		#set the upscaling
		res(x2)<-res(x)/up
		
		#resample the original raster
		x3<-resample(x, x2, method)
		
		# calculate the coordinates
		# resolution
		resX<-(x3@extent@xmax-x3@extent@xmin)/x3@ncols
		resY<-(x3@extent@ymax-x3@extent@ymin)/x3@nrows
		
		# coordinates of columns and rows
		xCoords <- seq(x3@extent@xmin+(resX/2), x3@extent@xmax-resX/2, resX)
		yCoords <- rev(seq(x3@extent@ymin+(resY/2), x3@extent@ymax-resY/2, resY))
		
		#table format
		xVals<-rep(xCoords, length(yCoords))
		yVals<-rep(yCoords, each=length(xCoords))
		coords<-cbind(xVals,yVals)
		
		#look up where the coordinates are in the new grid
		cells<-locate(y, coords)
		
		# the new values in the triangular grid
		mVal<-tapply(INDEX=cells, X=values(x3), mean, na.rm=na.rm)
		
		return(mVal)
	}
	
)
