## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(knitr)
library(icosa)
library(rgl)
knit_hooks$set(rgl = hook_rgl)

## ----first, rgl=TRUE,dev='png',dpi=300, fig.width=6, fig.height=4--------
library(icosa)
# create a trigrid class object
tri <- trigrid()

# the show() method displays basic information
tri

# plot the object in 3d
plot3d(tri, guides=F)

## ----crs, rgl=TRUE,dev='png',dpi=300-------------------------------------
tri@proj4string

## ----trigrid, rgl=TRUE,dev='png',dpi=300---------------------------------
# create a trigrid class object
gLow <- trigrid(tesselation=c(4,4))

# plot the object in 3d
plot3d(gLow, guides=F)

## ----hexagrid1, rgl=TRUE,dev='png',dpi=300-------------------------------
# create a hexagrid object
hLow <- hexagrid()

# plot it in 3d
plot3d(hLow, guides=F)

## ----hexagrid, rgl=TRUE,dev='png',dpi=300--------------------------------
# create a hexagrid object
hLow <- hexagrid(c(4,4))

# plot it in 3d
plot3d(hLow)

## ----tri2, rgl=TRUE,dev='png',dpi=300------------------------------------
# the beginning of the vertices matrix
head(gLow@vertices)

# the beginning of the faces matrix
head(gLow@faces)

## ----tri3, rgl=TRUE,dev='png',dpi=300------------------------------------
# grid radius
gLow@r

# grid center
gLow@center

## ----tri5, rgl=TRUE,dev='png',dpi=300------------------------------------
head(gLow@faceCenters)

## ----tri6, rgl=TRUE,dev='png',dpi=300------------------------------------
plot3d(gLow)
gridlabs3d(gLow, type="v", col="blue", cex=0.6)

## ----tri7, rgl=TRUE,dev='png',dpi=300------------------------------------
head(gLow@edges)

## ----tri8, rgl=TRUE,dev='png',dpi=300------------------------------------
gLow2 <- rotate(gLow) # random rotation
plot3d(gLow2)
guides3d(col="green")

## ----tri9, rgl=TRUE,dev='png',dpi=300------------------------------------
gLowSub <- subset(gLow, paste("F",1000:1800, sep=""))
plot3d(gLowSub)

## ----tri9b, rgl=TRUE,dev='png',dpi=300-----------------------------------
# numeric subscript: every 4th face
gLowSub2<-gLow[seq(1, length(gLow), 4)]
plot3d(gLowSub2)

## ----tri9e, rgl=TRUE,dev='png',dpi=300-----------------------------------
# numeric subscript: polar coordinates
gLowSub3<-gLow[c(lamax=30)]
plot3d(gLowSub3)

## ----tri9d, rgl=TRUE,dev='png',dpi=300-----------------------------------
# numeric subscript: polar coordinates
gLowSub4<-gLow[c(lamax=30, lamin=-30, lomin=-120,lomax=-60)]
plot3d(gLowSub4)

## ----belts, rgl=TRUE,dev='png',dpi=300-----------------------------------
# logical subscript
gLowSub5<-gLow[gLow@belts==17]

# the 17th belt
plot3d(gLow)
faces3d(gLowSub5, col="blue")

## ----belts2, rgl=TRUE,dev='png',dpi=300----------------------------------
# transform the faceCenter coordinates
longLat <- CarToPol(gLowSub5@faceCenters, norad=T)
mean(longLat[,2])

## ----tri9c, rgl=TRUE,dev='png',dpi=300-----------------------------------
str(gLow@skeleton)

## ----tri10, plot=TRUE, ,dev='png',dpi=300--------------------------------
hLow <- newsp(hLow)
# After this procedure finishes, a regular 2d plotting can  done:
plot(hLow)

## ----tri11, plot=TRUE, ,dev='png',dpi=300--------------------------------
# Lambert cylcindrical equal area projection
cea <- CRS("+proj=cea")
plot(hLow, projargs=cea)

## ----tri11B, plot=TRUE, ,dev='png',dpi=300-------------------------------
# The Mollweide projection
moll <- CRS("+proj=moll")
plot(hLow, projargs=moll)

## ----examplePaleo, plot=TRUE, ,dev='png',dpi=300-------------------------
#triangular grid
gLow<-newsp(gLow)

# load in a paleogeographic reconstruction
library(rgdal)
file<-system.file("extdata", "065.shx", package = "icosa")
paleo <- readOGR(file, "065")

# plot the grid (default longitude/latitude)
plot(gLow, border="gray", lty=3)

# the reconstruction
lines(paleo, lwd=2, col="blue")

## ----examplePaleo2, plot=TRUE, ,dev='png',dpi=300------------------------
# the Winkel tripel projection
wintri<-CRS("+proj=wintri")

# plot the grid (default longitude/latitude)
gLow2d<-SpPolygons(gLow, res=50) 			# create SpatialPolygons
gLow2dTrans<-spTransform(gLow2d, wintri) 	# transform projection
plot(gLow2dTrans, border="gray",lty=3) 		# plot

#transform the reconstruction
paleoTrans<-spTransform(paleo, CRS("+proj=wintri"))

# the reconstruction
lines(paleoTrans, lwd=2, col="blue")

## ----tri12, plot=TRUE, ,dev='png',dpi=300--------------------------------
# a very low resolution hexagrid
hVeryLow<-hexagrid(c(4))
# add 2d component
hVeryLow<-newsp(hVeryLow)
# the Robinson projection
robin <- CRS("+proj=robin")
# plot with labels
plot(hVeryLow, projargs=robin)
gridlabs(hVeryLow, type="f", cex=0.6,projargs=robin)

## ----tri13, echo=TRUE----------------------------------------------------
pos(hLow, c("P2", "F12", NA))

## ----tri14, echo=TRUE----------------------------------------------------
fl1<-facelayer(gLow) # the argument is the grid object to which the layer is linked
fl1
str(fl1)

## ----tri15, echo=TRUE----------------------------------------------------
length(fl1)

## ----tri16, echo=TRUE----------------------------------------------------
values(fl1) <-1:length(fl1)
values(fl1)[1:10]

## ----tri17, echo=TRUE----------------------------------------------------
# layer definition
fl2<-facelayer(gLow)
# all values should be one
values(fl2)[] <- 1

# layer arithmetics
fl1+fl2
fl1*4

## ----tri18, rgl=TRUE,dev='png',dpi=300-----------------------------------
a <-facelayer(gLow)
values(a) <- sample(c(T,F), length(a), replace=T)
plot3d(gLow, guides=F)
faces3d(a, col="green")

## ----tri19, rgl=TRUE,dev='png',dpi=300-----------------------------------
# new layer
b<-facelayer(gLow)
# sequenced values 
values(b)<-1:length(b)
# grid frame
plot3d(gLow)
# the heatmap
faces3d(b) 

## ----tri19b, rgl=TRUE,dev='png',dpi=300----------------------------------
# new layer
# grid frame
plot3d(gLow)
# the heatmap
faces3d(b, col=c("green", "brown")) 

## ----tri20, rgl=TRUE,dev='png',dpi=300-----------------------------------
pointdat <- rpsphere(5000) # generate 50000 random coordinates on a sphere of default radius
cells<-locate(gLow, pointdat)
# the return of this function is vector of cell names
head(cells)

## ----tri20b, rgl=TRUE,dev='png',dpi=300----------------------------------
tCell <- table(cells)
fl <- facelayer(gLow)
# [] invokes a method that save the values to places that correspond to the names argument of tCell
fl[] <-tCell #
plot3d(gLow)
faces3d(fl) # heat map of the point densities

## ----tri21, rgl=TRUE,dev='png',dpi=300-----------------------------------
cells2<- locate(hLow, pointdat)
b<-facelayer(hLow)
b[]<-table(cells2)
plot3d(hLow) 
faces3d(b)

## ----tri22, rgl=TRUE,dev='png',dpi=300-----------------------------------
# run function only on the first 300
fl<-occupied(hLow, pointdat[1:300,])

# after the SpatialPolygons object is calculated
# hLow<-newsp(hLow) # was run before

# the plot function can also be applied to the facelayer object
plot(fl, col="blue")

points(CarToPol(pointdat[1:300,]), col="red", pch=3, cex=0.7)

## ----tri22b, rgl=TRUE,dev='png',dpi=300----------------------------------
# the plot function can also be applied to the facelayer object
plot(fl, col="blue")

points(CarToPol(pointdat[1:300,]), col="red", pch=3, cex=0.7)
lines(hLow, col="gray")

## ----tri23, plot=TRUE,dev='png',dpi=300----------------------------------
file<-system.file("extdata", "TM_WORLD_BORDERS_SIMPL-0.3.shx", package = "icosa")
wo <- readOGR(file, "TM_WORLD_BORDERS_SIMPL-0.3")
plot(wo)	

## ----tri24, rgl=TRUE,dev='png',dpi=300-----------------------------------
# transform it to SpatialLines
woL <- as(wo, "SpatialLines")
woP <- as(woL, "SpatialPoints")

# the facelayer of the occupied cells
fL<-occupied(hLow, woP)

plot3d(fL, col="red")

## ----tri25, rgl=TRUE,dev='png',dpi=300-----------------------------------
# the facelayer of the occupied cells
gHigh<-trigrid(c(8,8))
fL<-occupied(gHigh, woL, f=10)

plot3d(fL, col="blue")

## ----tri25b, rgl=TRUE,dev='png',dpi=300----------------------------------
# plot the faces
plot3d(fL, col="blue", guides=F)
# and then on top, plot the actual lines
lines3d(woL, col="red", plot=F)

## ----tri26, rgl=TRUE,dev='png',dpi=300-----------------------------------
hHigh<- hexagrid(c(8,8))
# look up the polygons
f<-occupied(hHigh, wo)
# the empty grid
plot3d(hHigh, guides=F)

# the landmass of the world
faces3d(f, col="blue")

## ----tri26b, plot=TRUE,dev='png',dpi=300---------------------------------
# read in the file
file<-system.file("extdata", "prec1.bil", package = "icosa")
r<-raster(file)

# plot the raster
plot(r)

## ----tri27, rgl=TRUE,dev='png',dpi=300-----------------------------------

# resample the original data
resDat<-resample(r, hHigh, up=1, "ngb")

## ----tri28, rgl=TRUE,dev='png',dpi=300-----------------------------------
# new facelayer
layer<- facelayer(hHigh)
# fill in the new facelayer
layer[]<-resDat

## ----tri29, rgl=TRUE,dev='png',dpi=300-----------------------------------
# the grid 
plot3d(hHigh)
# the 
faces3d(layer, col=c("blue", "cyan", "yellow", "orange", "red"))

## ----tri30, plot=TRUE,dev='png',dpi=300----------------------------------
# the grid 
hHigh<-newsp(hHigh)
# the 
plot(layer, col=c("blue", "cyan", "yellow", "orange", "red"))

## ----tri31, rgl=TRUE,dev='png',dpi=300-----------------------------------
# sphere 1
aSphere<-rpsphere(n=500, origin=c(0,0,0), radius=1)
# sphere 2
bSphere<-rpsphere(n=500, origin=c(1,1,1), radius=3)
points3d(aSphere, col="blue")
points3d(bSphere, col="green")

## ----tri4, plot=TRUE,dev='png',dpi=300-----------------------------------
# coordinate transformations from cartesian to polar:
v2d <- CarToPol(gLow@vertices)
plot(v2d, xlim=c(-180,180), ylim=c(-90,90))

# coordinate transformation from polar to cartesian
longLatMat<-rbind(c(35,20), c(45,50))
PolToCar(longLatMat)

## ----triarc, plot=TRUE,dev='png',dpi=300---------------------------------
#great circle distance matrix between the facecenters
amat<-arcdistmat(hLow@faceCenters, radius=hLow@r, origin=hLow@center)

# the relationship of the first 6 points
amat[1:6,1:6]

## ----triarc2, plot=TRUE,dev='png',dpi=300--------------------------------
randPoints<-rpsphere(500)
#great circle distance matrix between the facecenters
amat<-arcdistmat(hLow@faceCenters, randPoints, radius=hLow@r, origin=hLow@center)

# the relationship of the first 6 points
amat[1:6,1:6]

